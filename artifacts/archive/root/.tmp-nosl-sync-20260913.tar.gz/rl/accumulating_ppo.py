"""MaskablePPO with optimizer-level gradient accumulation."""

from __future__ import annotations

import time
from contextlib import nullcontext
from dataclasses import dataclass
from threading import Thread
from types import MethodType

import numpy as np
import torch as th
import torch.nn.functional as F
from gymnasium import spaces
from sb3_contrib import MaskablePPO
from sb3_contrib.common.maskable.utils import get_action_masks, is_masking_supported
from stable_baselines3.common.utils import explained_variance, obs_as_tensor

from env.core import vocab as V
from env.core.run_env import unpack_nosl_observation_buffer
from rl.hierarchical_returns import compute_hierarchical_returns
from rl.nosl_replay import NOSLISAZReplayBuffer


NOSL_IS_AZ_SEARCH_MODES = {
    "puct": 0,
    "gumbel": 1,
    "full_gumbel": 2,
}


def _leaf_observation_as_tensor(observation, device):
    """Move a compact leaf batch to the device with one copy per dtype.

    The split combat encoder exposes many small fields.  Calling
    ``obs_as_tensor`` on the dict moves each field independently, which turns
    a small leaf batch into dozens of CUDA launch/copy operations.  All combat
    fields are either int64 categorical arrays or float32 scalar arrays, so we
    concatenate fields of the same dtype on the host, transfer two contiguous
    buffers, and reconstruct field views on the device.  The tensor values and
    shapes are unchanged; this is purely a transport optimization.
    """
    groups: dict[np.dtype, list[tuple[str, np.ndarray]]] = {}
    for key, value in observation.items():
        array = np.ascontiguousarray(value)
        groups.setdefault(array.dtype, []).append((str(key), array))
    if not groups:
        return {}
    result = {}
    for dtype, fields in groups.items():
        if dtype not in (np.dtype(np.int64), np.dtype(np.float32)):
            # Keep compatibility with optional extensions that may add a new
            # scalar dtype before the encoder contract is updated.
            return obs_as_tensor(observation, device)
        offsets = []
        total = 0
        flat_fields = []
        for key, array in fields:
            flat = array.reshape(-1)
            offsets.append((key, array.shape, total, flat.size))
            flat_fields.append(flat)
            total += flat.size
        packed = np.concatenate(flat_fields) if len(flat_fields) > 1 else flat_fields[0]
        packed_tensor = th.as_tensor(packed, device=device)
        for key, shape, offset, size in offsets:
            result[key] = packed_tensor[offset:offset + size].reshape(shape)
    return result


def _fill_nosl_combat_value_targets(
    samples: list[dict], final_hp: float
) -> int:
    """Assign one normalized terminal-HP target to every root in a fight."""
    target = float(np.clip(final_hp, 0.0, 1.0))
    if not np.isfinite(target):
        raise ValueError("final combat HP must be finite")
    for sample in samples:
        sample["value_target"] = target
    return len(samples)


@dataclass(frozen=True)
class PPOLossComponents:
    policy_loss: th.Tensor
    value_loss: th.Tensor
    entropy_loss: th.Tensor
    approx_kl: th.Tensor
    clip_fraction: th.Tensor
    valid_samples: int
    combat_samples: int
    overworld_samples: int
    combat_value_loss: th.Tensor | None
    overworld_value_loss: th.Tensor | None


def _phase_balanced_mean(
    values: th.Tensor,
    *,
    valid: th.Tensor,
    combat: th.Tensor,
) -> th.Tensor:
    means = []
    for group in (valid & combat, valid & ~combat):
        if bool(group.any()):
            means.append(values[group].mean())
    if not means:
        raise RuntimeError("PPO minibatch has no valid hierarchical samples")
    return th.stack(means).mean()


def ppo_loss_components(
    *,
    hierarchical: bool,
    normalize_advantage: bool,
    observations,
    advantages: th.Tensor,
    returns: th.Tensor,
    old_values: th.Tensor,
    old_log_prob: th.Tensor,
    values: th.Tensor,
    log_prob: th.Tensor,
    entropy: th.Tensor | None,
    clip_range: float,
    clip_range_vf: float | None,
    skip_combat: bool = False,
) -> PPOLossComponents:
    """Compute the shared native/distributed PPO objective.

    Hierarchical rollouts use NaN to mark an overworld macro transition whose
    combat option did not finish before the rollout boundary. Those samples are
    excluded. Combat and overworld means are then weighted equally so the much
    larger number of combat clicks cannot drown out strategic decisions.
    """
    if clip_range_vf is None:
        values_pred = values
    else:
        values_pred = old_values + th.clamp(
            values - old_values,
            -clip_range_vf,
            clip_range_vf,
        )

    ratio = th.exp(log_prob - old_log_prob)
    clipped_ratio = th.clamp(ratio, 1 - clip_range, 1 + clip_range)
    entropy_per_sample = log_prob if entropy is None else -entropy
    kl_per_sample = (th.exp(log_prob - old_log_prob) - 1) - (
        log_prob - old_log_prob
    )
    clipped_per_sample = (th.abs(ratio - 1) > clip_range).float()

    if not hierarchical:
        normalized_advantages = advantages
        if normalize_advantage:
            normalized_advantages = (
                advantages - advantages.mean()
            ) / (advantages.std() + 1e-8)
        policy_loss = -th.min(
            normalized_advantages * ratio,
            normalized_advantages * clipped_ratio,
        ).mean()
        value_loss = F.mse_loss(returns, values_pred)
        return PPOLossComponents(
            policy_loss=policy_loss,
            value_loss=value_loss,
            entropy_loss=entropy_per_sample.mean(),
            approx_kl=kl_per_sample.mean(),
            clip_fraction=clipped_per_sample.mean(),
            valid_samples=int(advantages.numel()),
            combat_samples=0,
            overworld_samples=0,
            combat_value_loss=None,
            overworld_value_loss=None,
        )

    phase = observations["phase"].long().reshape(-1)
    combat = phase == V.PHASE_VOCAB_INDEX["combat"]
    valid = th.isfinite(advantages) & th.isfinite(returns)
    if skip_combat:
        valid = valid & ~combat
    if not bool(valid.any()):
        zero = values.sum() * 0.0
        return PPOLossComponents(
            policy_loss=zero,
            value_loss=zero,
            entropy_loss=zero,
            approx_kl=zero.detach(),
            clip_fraction=zero.detach(),
            valid_samples=0,
            combat_samples=0,
            overworld_samples=0,
            combat_value_loss=None,
            overworld_value_loss=None,
        )
    normalized_advantages = th.where(valid, advantages, th.zeros_like(advantages))
    if normalize_advantage:
        normalized_advantages = normalized_advantages.clone()
        for group in (valid & combat, valid & ~combat):
            count = int(group.sum().item())
            if count > 1:
                selected = normalized_advantages[group]
                normalized_advantages[group] = (
                    selected - selected.mean()
                ) / (selected.std(unbiased=False) + 1e-8)

    policy_per_sample = -th.min(
        normalized_advantages * ratio,
        normalized_advantages * clipped_ratio,
    )
    safe_returns = th.where(valid, returns, values_pred.detach())
    value_per_sample = (safe_returns - values_pred).square()
    policy_loss = _phase_balanced_mean(
        policy_per_sample, valid=valid, combat=combat
    )
    value_loss = _phase_balanced_mean(
        value_per_sample, valid=valid, combat=combat
    )
    entropy_loss = _phase_balanced_mean(
        entropy_per_sample, valid=valid, combat=combat
    )

    combat_valid = valid & combat
    overworld_valid = valid & ~combat
    return PPOLossComponents(
        policy_loss=policy_loss,
        value_loss=value_loss,
        entropy_loss=entropy_loss,
        approx_kl=kl_per_sample[valid].mean(),
        clip_fraction=clipped_per_sample[valid].mean(),
        valid_samples=int(valid.sum().item()),
        combat_samples=int(combat_valid.sum().item()),
        overworld_samples=int(overworld_valid.sum().item()),
        combat_value_loss=(
            value_per_sample[combat_valid].mean()
            if bool(combat_valid.any()) else None
        ),
        overworld_value_loss=(
            value_per_sample[overworld_valid].mean()
            if bool(overworld_valid.any()) else None
        ),
    )


class AccumulatingMaskablePPO(MaskablePPO):
    """MaskablePPO whose optimizer can consume several micro-batches per step.

    ``batch_size`` remains the number of rollout samples materialized for one
    forward/backward pass. ``gradient_accumulation_steps`` controls how many of
    those gradients are averaged before clipping and stepping the optimizer.
    """

    def __init__(
        self,
        *args,
        gradient_accumulation_steps: int = 1,
        performance_profile: bool = False,
        amp_mode: str = "off",
        hierarchical_combat_hp: bool = False,
        combat_hp_gamma: float = 1.0,
        combat_hp_gae_lambda: float = 0.95,
        reasoning_coef: float = 0.0,
        reasoning_batch_size: int = 16,
        reasoning_updates: int = 1,
        reasoning_gradient_accumulation_steps: int = 1,
        nosl_is_az: bool = False,
        nosl_is_az_inner_only: bool = False,
        nosl_is_az_cpp: bool = False,
        nosl_is_az_simulations: int = 8,
        nosl_is_az_depth: int = 3,
        nosl_is_az_end_turn_as_leaf: bool = False,
        nosl_is_az_rollout_steps: int = 0,
        nosl_is_az_c_puct: float = 1.5,
        nosl_is_az_temperature: float = 1.0,
        nosl_is_az_prior_temperature: float = 1.0,
        nosl_is_az_search_mode: str = "puct",
        nosl_is_az_paper_full_gumbel: bool = False,
        nosl_is_az_gumbel_candidates: int = 0,
        nosl_is_az_gumbel_scale: float = 1.0,
        nosl_is_az_gumbel_value_scale: float = 0.1,
        nosl_is_az_gumbel_max_visit_init: float = 50.0,
        nosl_is_az_gumbel_rescale_q: bool = True,
        nosl_is_az_gumbel_use_mixed_value: bool = True,
        nosl_is_az_gumbel_interior_uniformity: float = 0.0,
        nosl_is_az_gumbel_interior_coverage_fraction: float = 0.0,
        nosl_is_az_gumbel_interior_value_mode: int = 2,
        nosl_is_az_gumbel_interior_max_mix_visits: float = 64.0,
        nosl_is_az_dirichlet_alpha: float = 0.0,
        nosl_is_az_dirichlet_epsilon: float = 0.0,
        nosl_is_az_master_nonce: int = 0x4E4F534C4953415A,
        nosl_is_az_batch_size: int = 64,
        nosl_is_az_micro_batch_size: int = 2048,
        nosl_is_az_replay_enabled: bool = True,
        nosl_is_az_replay_capacity: int = 131072,
        nosl_is_az_replay_min_size: int = 1,
        nosl_is_az_leaf_batch_size: int = 64,
        nosl_is_az_updates: int = 1,
        nosl_is_az_policy_coef: float = 1.0,
        nosl_is_az_value_coef: float = 0.5,
        **kwargs,
    ) -> None:
        if gradient_accumulation_steps < 1:
            raise ValueError("gradient_accumulation_steps must be at least 1")
        if amp_mode not in ("off", "bf16"):
            raise ValueError("amp_mode must be 'off' or 'bf16'")
        if not 0.0 <= combat_hp_gamma <= 1.0:
            raise ValueError("combat_hp_gamma must be in [0, 1]")
        if not 0.0 <= combat_hp_gae_lambda <= 1.0:
            raise ValueError("combat_hp_gae_lambda must be in [0, 1]")
        if reasoning_coef < 0.0:
            raise ValueError("reasoning_coef must be non-negative")
        if reasoning_batch_size < 1:
            raise ValueError("reasoning_batch_size must be at least 1")
        if reasoning_updates < 0:
            raise ValueError("reasoning_updates must be non-negative")
        if reasoning_gradient_accumulation_steps < 1:
            raise ValueError(
                "reasoning_gradient_accumulation_steps must be at least 1"
            )
        if nosl_is_az_simulations < 1 or nosl_is_az_depth < 0:
            raise ValueError(
                "NOSL-IS-AZ simulations must be positive and depth must be "
                "non-negative (0 means unlimited node expansion)"
            )
        if nosl_is_az_rollout_steps < 0:
            raise ValueError("NOSL-IS-AZ rollout steps must be non-negative")
        if nosl_is_az_c_puct < 0.0 or nosl_is_az_temperature < 0.0:
            raise ValueError("NOSL-IS-AZ c_puct/temperature must be non-negative")
        if not np.isfinite(nosl_is_az_prior_temperature) or nosl_is_az_prior_temperature <= 0.0:
            raise ValueError("NOSL-IS-AZ prior temperature must be positive and finite")
        if nosl_is_az_search_mode not in NOSL_IS_AZ_SEARCH_MODES:
            raise ValueError(
                "NOSL-IS-AZ search mode must be puct, gumbel, or full_gumbel"
            )
        if nosl_is_az_search_mode != "puct" and not nosl_is_az_cpp:
            raise ValueError("Gumbel NOSL-IS-AZ search requires the C++ backend")
        if nosl_is_az_gumbel_candidates < 0:
            raise ValueError("NOSL-IS-AZ Gumbel candidates must be non-negative")
        for name, value in (
            ("Gumbel scale", nosl_is_az_gumbel_scale),
            ("Gumbel value scale", nosl_is_az_gumbel_value_scale),
            ("Gumbel max visit init", nosl_is_az_gumbel_max_visit_init),
        ):
            if not np.isfinite(value) or value < 0.0:
                raise ValueError(f"NOSL-IS-AZ {name} must be non-negative and finite")
        if nosl_is_az_dirichlet_alpha < 0.0:
            raise ValueError("NOSL-IS-AZ Dirichlet alpha must be non-negative")
        if not 0.0 <= nosl_is_az_dirichlet_epsilon <= 1.0:
            raise ValueError("NOSL-IS-AZ Dirichlet epsilon must be in [0, 1]")
        if nosl_is_az_dirichlet_epsilon > 0.0 and nosl_is_az_dirichlet_alpha <= 0.0:
            raise ValueError(
                "NOSL-IS-AZ Dirichlet alpha must be positive when epsilon > 0"
            )
        if nosl_is_az_batch_size < 1 or nosl_is_az_updates < 1:
            raise ValueError("NOSL-IS-AZ batch size/updates must be positive")
        if nosl_is_az_micro_batch_size < 1:
            raise ValueError("NOSL-IS-AZ micro batch size must be positive")
        if nosl_is_az_replay_capacity < 1:
            raise ValueError("NOSL-IS-AZ replay capacity must be positive")
        if not 1 <= nosl_is_az_replay_min_size <= nosl_is_az_replay_capacity:
            raise ValueError(
                "NOSL-IS-AZ replay min size must be in [1, replay capacity]"
            )
        if nosl_is_az_leaf_batch_size < 1:
            raise ValueError("NOSL-IS-AZ leaf batch size must be positive")
        if nosl_is_az_policy_coef < 0.0 or nosl_is_az_value_coef < 0.0:
            raise ValueError("NOSL-IS-AZ loss coefficients must be non-negative")
        if nosl_is_az_inner_only and not nosl_is_az:
            raise ValueError("NOSL-IS-AZ inner-only mode requires nosl_is_az")
        self.gradient_accumulation_steps = int(gradient_accumulation_steps)
        self.performance_profile = bool(performance_profile)
        self.amp_mode = amp_mode
        # Combat AZ targets are fight-local terminal-HP values.  Keep the
        # overworld/combat return split enabled automatically so combat PPO can
        # be removed without changing the strategic return calculation.
        self.nosl_is_az = bool(nosl_is_az)
        self.nosl_is_az_inner_only = bool(nosl_is_az_inner_only)
        self.nosl_is_az_cpp = bool(nosl_is_az_cpp)
        self.hierarchical_combat_hp = bool(
            hierarchical_combat_hp or self.nosl_is_az
        )
        self.combat_hp_gamma = float(combat_hp_gamma)
        self.combat_hp_gae_lambda = float(combat_hp_gae_lambda)
        self.reasoning_coef = float(reasoning_coef)
        self.reasoning_batch_size = int(reasoning_batch_size)
        self.reasoning_updates = int(reasoning_updates)
        self.reasoning_gradient_accumulation_steps = int(
            reasoning_gradient_accumulation_steps
        )
        self.nosl_is_az_simulations = int(nosl_is_az_simulations)
        self.nosl_is_az_depth = int(nosl_is_az_depth)
        self.nosl_is_az_end_turn_as_leaf = bool(nosl_is_az_end_turn_as_leaf)
        self.nosl_is_az_rollout_steps = int(nosl_is_az_rollout_steps)
        self.nosl_is_az_c_puct = float(nosl_is_az_c_puct)
        self.nosl_is_az_temperature = float(nosl_is_az_temperature)
        self.nosl_is_az_prior_temperature = float(nosl_is_az_prior_temperature)
        self.nosl_is_az_search_mode = str(nosl_is_az_search_mode)
        self.nosl_is_az_paper_full_gumbel = bool(
            nosl_is_az_paper_full_gumbel
        )
        self.nosl_is_az_root_search_mode = NOSL_IS_AZ_SEARCH_MODES[
            self.nosl_is_az_search_mode
        ]
        self.nosl_is_az_gumbel_candidates = int(nosl_is_az_gumbel_candidates)
        self.nosl_is_az_gumbel_scale = float(nosl_is_az_gumbel_scale)
        self.nosl_is_az_gumbel_value_scale = float(nosl_is_az_gumbel_value_scale)
        self.nosl_is_az_gumbel_max_visit_init = float(
            nosl_is_az_gumbel_max_visit_init
        )
        self.nosl_is_az_gumbel_rescale_q = bool(nosl_is_az_gumbel_rescale_q)
        self.nosl_is_az_gumbel_use_mixed_value = bool(
            nosl_is_az_gumbel_use_mixed_value
        )
        self.nosl_is_az_gumbel_interior_uniformity = float(
            nosl_is_az_gumbel_interior_uniformity
        )
        self.nosl_is_az_gumbel_interior_coverage_fraction = float(
            nosl_is_az_gumbel_interior_coverage_fraction
        )
        self.nosl_is_az_gumbel_interior_value_mode = int(
            nosl_is_az_gumbel_interior_value_mode
        )
        self.nosl_is_az_gumbel_interior_max_mix_visits = float(
            nosl_is_az_gumbel_interior_max_mix_visits
        )
        if not 0.0 <= self.nosl_is_az_gumbel_interior_coverage_fraction <= 1.0:
            raise ValueError(
                "NOSL Full-Gumbel interior coverage fraction must be in [0, 1]"
            )
        if self.nosl_is_az_gumbel_interior_value_mode not in (0, 1, 2):
            raise ValueError(
                "NOSL Full-Gumbel interior value mode must be 0, 1, or 2"
            )
        if (
            not np.isfinite(self.nosl_is_az_gumbel_interior_max_mix_visits)
            or self.nosl_is_az_gumbel_interior_max_mix_visits <= 0.0
        ):
            raise ValueError(
                "NOSL Full-Gumbel interior max-mix visits must be positive and finite"
            )
        self.nosl_is_az_dirichlet_alpha = float(nosl_is_az_dirichlet_alpha)
        self.nosl_is_az_dirichlet_epsilon = float(nosl_is_az_dirichlet_epsilon)
        if self.nosl_is_az_paper_full_gumbel:
            # Keep the serialized model metadata aligned with the native
            # strict-paper path.  The native constructor repeats this
            # canonicalization so direct environment callers get the same
            # semantics.
            if self.nosl_is_az_search_mode != "full_gumbel":
                raise ValueError(
                    "paper Full-Gumbel mode requires search_mode='full_gumbel'"
                )
            self.nosl_is_az_prior_temperature = 1.0
            # DeepMind mctx's paper policy uses max_num_considered_actions=16.
            # The legacy mode keeps 0 as the project-specific "all legal"
            # convention; strict paper mode must use the paper default.
            self.nosl_is_az_gumbel_candidates = 16
            self.nosl_is_az_gumbel_scale = 1.0
            # Match mctx.qtransform_completed_by_mix_value's value_scale=0.1.
            self.nosl_is_az_gumbel_value_scale = 0.1
            self.nosl_is_az_gumbel_max_visit_init = 50.0
            self.nosl_is_az_gumbel_rescale_q = True
            self.nosl_is_az_gumbel_use_mixed_value = True
            self.nosl_is_az_gumbel_interior_uniformity = 0.0
            self.nosl_is_az_gumbel_interior_coverage_fraction = 0.0
            self.nosl_is_az_gumbel_interior_value_mode = 0
            self.nosl_is_az_gumbel_interior_max_mix_visits = 64.0
            self.nosl_is_az_dirichlet_alpha = 0.0
            self.nosl_is_az_dirichlet_epsilon = 0.0
        self.nosl_is_az_master_nonce = int(nosl_is_az_master_nonce)
        self.nosl_is_az_batch_size = int(nosl_is_az_batch_size)
        self.nosl_is_az_micro_batch_size = int(nosl_is_az_micro_batch_size)
        self.nosl_is_az_replay_enabled = bool(nosl_is_az_replay_enabled)
        self.nosl_is_az_replay_capacity = int(nosl_is_az_replay_capacity)
        self.nosl_is_az_replay_min_size = int(nosl_is_az_replay_min_size)
        self.nosl_is_az_leaf_batch_size = int(nosl_is_az_leaf_batch_size)
        self.nosl_is_az_updates = int(nosl_is_az_updates)
        self.nosl_is_az_policy_coef = float(nosl_is_az_policy_coef)
        self.nosl_is_az_value_coef = float(nosl_is_az_value_coef)
        self._nosl_is_az_samples = []
        # When replay is disabled, this transient list is the complete
        # effective batch for the current update.  It is intentionally not
        # serialized into checkpoints.
        self._nosl_is_az_fresh_samples = []
        self._nosl_is_az_pending_fights = []
        self._nosl_is_az_replay = None
        self._nosl_is_az_replay_prepare_stats = {}
        self._reasoning_rollout_samples = []
        self._reasoning_compile_thread: Thread | None = None
        self._reasoning_compile_error: BaseException | None = None
        self._performance_rollout = None
        self._hierarchical_rollout_stats = None
        super().__init__(*args, **kwargs)
        if self.amp_mode != "off" and self.device.type != "cuda":
            raise ValueError("bf16 AMP requires a CUDA device")

    def _excluded_save_params(self) -> list[str]:
        """Exclude transient reasoning transcripts from SB3 checkpoints.

        The captured rollout traces are regenerated after every rollout.  They
        can contain hundreds of thousands of long token sequences and are not
        needed to resume the policy, so serializing them makes checkpoints
        needlessly multi-gigabyte.
        """
        return [
            *super()._excluded_save_params(),
            "_reasoning_rollout_samples",
            "_nosl_is_az_samples",
            "_nosl_is_az_fresh_samples",
            "_nosl_is_az_pending_fights",
            "_nosl_is_az_replay",
            "_nosl_is_az_replay_prepare_stats",
            "_nosl_is_az_metric_sums",
            "_nosl_is_az_metric_sumsq",
            "_nosl_is_az_metric_counts",
            "_nosl_is_az_metric_count",
            "_nosl_is_az_policy_loss_sum",
            "_nosl_is_az_policy_weight_sum",
            "_nosl_is_az_value_loss_sum",
        ]

    def _ensure_nosl_is_az_replay(self) -> NOSLISAZReplayBuffer:
        """Create runtime replay state, including when loading an old checkpoint."""
        # A disabled replay path must never allocate the large fixed-capacity
        # arrays.  Keep this guard explicit so an accidental call from a new
        # code path fails loudly instead of silently changing the experiment.
        if not bool(getattr(self, "nosl_is_az_replay_enabled", True)):
            raise RuntimeError("NOSL-IS-AZ replay is disabled")
        capacity = int(getattr(self, "nosl_is_az_replay_capacity", 131072))
        self.nosl_is_az_replay_capacity = capacity
        self.nosl_is_az_replay_min_size = int(
            getattr(self, "nosl_is_az_replay_min_size", 1)
        )
        self.nosl_is_az_micro_batch_size = int(
            getattr(self, "nosl_is_az_micro_batch_size", 2048)
        )
        replay = getattr(self, "_nosl_is_az_replay", None)
        if replay is not None:
            if replay.capacity != capacity:
                raise RuntimeError(
                    "cannot resize a populated NOSL replay buffer at runtime"
                )
            return replay

        core = getattr(self.policy, "core", None)
        observation_keys = getattr(
            core, "combat_observation_keys", self.observation_space.spaces.keys()
        )
        action_dim = int(getattr(self.action_space, "n", 0))
        replay = NOSLISAZReplayBuffer(
            capacity=capacity,
            observation_space=self.observation_space,
            observation_keys=observation_keys,
            action_dim=action_dim,
        )
        self._nosl_is_az_replay = replay
        return replay

    def _nosl_is_az_observation_keys(self) -> tuple[str, ...]:
        """Return the combat observation contract without creating replay."""
        core = getattr(self.policy, "core", None)
        keys = getattr(core, "combat_observation_keys", None)
        if keys is None:
            keys = self.observation_space.spaces.keys()
        return tuple(
            key for key in keys if key in self.observation_space.spaces
        )

    def _nosl_samples_to_batch(self, samples: list[dict]) -> dict[str, object]:
        """Materialize fresh labelled roots in the replay batch contract."""
        if not samples:
            raise ValueError("cannot materialize an empty NOSL sample batch")
        keys = self._nosl_is_az_observation_keys()
        action_dim = int(getattr(self.action_space, "n", 0))
        observations = {
            key: np.stack([sample["observation"][key] for sample in samples])
            for key in keys
        }
        action_masks = np.stack(
            [np.asarray(sample["action_mask"], dtype=bool) for sample in samples]
        )
        policy_targets = np.stack(
            [np.asarray(sample["policy_target"], dtype=np.float32) for sample in samples]
        )
        policy_weights = np.asarray(
            [sample.get("policy_weight", 1.0) for sample in samples],
            dtype=np.float32,
        )
        value_targets = np.asarray(
            [sample["value_target"] for sample in samples], dtype=np.float32
        )
        expected = (len(samples), action_dim)
        if action_masks.shape != expected or policy_targets.shape != expected:
            raise ValueError(
                "invalid fresh NOSL action/policy shape: "
                f"{action_masks.shape}/{policy_targets.shape}; expected {expected}"
            )
        if policy_weights.shape != (len(samples),) or not np.all(
            np.isfinite(policy_weights) & (policy_weights >= 0.0)
        ):
            raise ValueError(
                "fresh NOSL policy weights must be finite and non-negative"
            )
        return {
            "observations": observations,
            "action_masks": action_masks,
            "policy_targets": policy_targets,
            "policy_weights": policy_weights,
            "value_targets": value_targets,
            # The no-replay path has no persistent sample ids.  Keeping a
            # local ordinal makes diagnostics and compatibility callers easy.
            "sample_ids": np.arange(len(samples), dtype=np.uint64),
        }

    def autocast_context(self):
        if self.amp_mode == "bf16":
            return th.autocast(device_type="cuda", dtype=th.bfloat16)
        return nullcontext()

    def configure_nosl_is_az_inner_only(self) -> tuple[int, int]:
        """Freeze everything except the combat specialist.

        Shared tokenizers must stay frozen as well: changing them through the
        combat loss would also change the supposedly fixed overworld policy.
        """
        if not self.nosl_is_az or not self.nosl_is_az_inner_only:
            raise ValueError("NOSL-IS-AZ inner-only mode is not enabled")
        core = getattr(self.policy, "core", None)
        combat = getattr(core, "combat", None)
        if combat is None or getattr(core, "overworld", None) is None:
            raise ValueError(
                "NOSL-IS-AZ inner-only mode requires a split specialist policy"
            )
        for parameter in self.policy.parameters():
            parameter.requires_grad_(False)
        for parameter in combat.parameters():
            parameter.requires_grad_(True)
        frozen = sum(
            parameter.numel()
            for parameter in self.policy.parameters()
            if not parameter.requires_grad
        )
        trainable = sum(
            parameter.numel()
            for parameter in self.policy.parameters()
            if parameter.requires_grad
        )
        return frozen, trainable

    def _sync_device(self) -> None:
        if self.device.type == "cuda":
            th.cuda.synchronize(self.device)

    def configure_hierarchical_combat_hp(
        self,
        *,
        enabled: bool,
        combat_gamma: float = 1.0,
        combat_gae_lambda: float = 0.95,
        reset_combat_value: bool = False,
        reset_seed: int = 0,
    ) -> int:
        if not 0.0 <= combat_gamma <= 1.0:
            raise ValueError("combat_gamma must be in [0, 1]")
        if not 0.0 <= combat_gae_lambda <= 1.0:
            raise ValueError("combat_gae_lambda must be in [0, 1]")
        if self.nosl_is_az and not enabled:
            raise ValueError(
                "NOSL-IS-AZ requires hierarchical combat returns; disabling "
                "the combat phase would re-enable the PPO objective"
            )
        self.hierarchical_combat_hp = bool(enabled or self.nosl_is_az)
        self.combat_hp_gamma = float(combat_gamma)
        self.combat_hp_gae_lambda = float(combat_gae_lambda)
        if not reset_combat_value:
            return 0
        return self.reset_combat_value_head(seed=reset_seed)

    def reset_combat_value_head(self, *, seed: int = 0) -> int:
        """Reset only the critic whose target changes to terminal combat HP."""
        core = getattr(self.policy, "core", None)
        combat = getattr(core, "combat", None)
        value_mlp = getattr(combat, "value_mlp", None)
        value_head = getattr(combat, "value_head", None)
        if value_mlp is None or value_head is None:
            raise ValueError(
                "hierarchical combat-HP mode requires a split specialist policy"
            )

        modules = (value_mlp, value_head)
        parameters = {
            parameter
            for module in modules
            for parameter in module.parameters()
        }
        cuda_devices = sorted({
            parameter.device.index
            for parameter in parameters
            if parameter.is_cuda and parameter.device.index is not None
        })
        with th.random.fork_rng(devices=cuda_devices):
            th.manual_seed(seed)
            if cuda_devices:
                th.cuda.manual_seed_all(seed)
            for module in modules:
                for child in module.modules():
                    if isinstance(child, th.nn.Linear):
                        child.reset_parameters()

        optimizer = getattr(self.policy, "optimizer", None)
        if optimizer is not None:
            for parameter in parameters:
                optimizer.state.pop(parameter, None)
        return len(parameters)

    @staticmethod
    def _next_phase_hp(new_obs, dones, infos):
        phases = np.asarray(new_obs["phase"]).reshape(len(dones), -1)[:, 0].copy()
        hp = np.asarray(new_obs["run_hp"], dtype=np.float32).reshape(
            len(dones), -1
        )[:, 0].copy()
        interrupted = np.zeros(len(dones), dtype=bool)
        for idx, done in enumerate(dones):
            info = infos[idx]
            interrupted[idx] = bool(
                info.get("TimeLimit.truncated", False)
                or info.get("dead_screen", False)
            )
            terminal_obs = info.get("terminal_observation") if done else None
            if isinstance(terminal_obs, dict):
                phases[idx] = np.asarray(terminal_obs["phase"]).reshape(-1)[0]
                hp[idx] = np.asarray(
                    terminal_obs["run_hp"], dtype=np.float32
                ).reshape(-1)[0]
        return phases, hp, interrupted

    def _apply_hierarchical_returns(self, rollout_buffer, captured) -> None:
        if len(captured) != rollout_buffer.buffer_size:
            raise RuntimeError(
                "hierarchical transition capture length mismatch: "
                f"{len(captured)} != {rollout_buffer.buffer_size}"
            )
        with th.no_grad():
            last_values = self.policy.predict_values(
                obs_as_tensor(self._last_obs, self.device)
            ).detach().cpu().numpy().reshape(-1)

        phases = np.asarray(rollout_buffer.observations["phase"])[..., 0]
        raw_rewards = np.stack([item[0] for item in captured])
        dones = np.stack([item[1] for item in captured])
        next_phases = np.stack([item[2] for item in captured])
        next_hp = np.stack([item[3] for item in captured])
        interrupted = np.stack([item[4] for item in captured])
        rewards, returns, advantages, stats = compute_hierarchical_returns(
            phases=phases,
            values=rollout_buffer.values,
            raw_rewards=raw_rewards,
            dones=dones,
            next_phases=next_phases,
            next_hp=next_hp,
            interrupted=interrupted,
            last_values=last_values,
            combat_phase=V.PHASE_VOCAB_INDEX["combat"],
            overworld_gamma=self.gamma,
            overworld_gae_lambda=self.gae_lambda,
            combat_gamma=self.combat_hp_gamma,
            combat_gae_lambda=self.combat_hp_gae_lambda,
        )
        rollout_buffer.rewards[...] = rewards
        rollout_buffer.returns[...] = returns
        rollout_buffer.advantages[...] = advantages
        self._hierarchical_rollout_stats = stats
        for key, value in vars(stats).items():
            self.logger.record(f"hierarchical/{key}", value)

    def collect_rollouts(self, env, callback, rollout_buffer,
                         n_rollout_steps, use_masking=True):
        # A previous update normally joins before starting the next rollout;
        # keep this guard so an early callback/error cannot leave a compiler
        # thread racing with a later buffer reuse.
        self._wait_for_reasoning_samples()
        if self.amp_mode == "bf16" and not getattr(
            self.policy, "supports_bf16_rollout", False
        ):
            raise TypeError(
                "bf16 rollout requires a policy that returns float32 values "
                "and log-probabilities"
            )
        captured = []
        reasoning_samples = []
        original_step_wait = env.step_wait
        original_step_async = env.step_async
        uncaptured_step_wait = env.step_wait

        if self.hierarchical_combat_hp:
            def capture_step_wait(_env):
                new_obs, rewards, dones, infos = uncaptured_step_wait()
                phases, hp, interrupted = self._next_phase_hp(
                    new_obs, dones, infos
                )
                captured.append((
                    np.asarray(rewards, dtype=np.float32).copy(),
                    np.asarray(dones, dtype=bool).copy(),
                    phases,
                    hp,
                    interrupted,
                ))
                return new_obs, rewards, dones, infos

            env.step_wait = MethodType(capture_step_wait, env)

        reasoning_enabled = (
            self.reasoning_coef > 0.0
            and self.reasoning_updates > 0
            and hasattr(getattr(self.policy, "core", None), "reasoning_loss")
        )
        pending_reasoning = {}
        # Keep only the small action/trace side channel during collection.  A
        # previous implementation copied every observation field for all
        # environments in step_async, even though SB3 writes the same
        # pre-action observations into rollout_buffer immediately afterwards.
        # That copy was pure CPU/memory-bandwidth overhead on every vector step.
        raw_reasoning_steps = []
        if reasoning_enabled:
            captured_step_wait = env.step_wait

            def capture_reasoning_step_async(_env, actions):
                pending_reasoning["actions"] = (
                    np.asarray(actions).reshape(-1).copy()
                )
                return original_step_async(actions)

            def capture_reasoning_step_wait(_env):
                result = captured_step_wait()
                _new_obs, _rewards, _dones, infos = result
                actions = pending_reasoning.pop("actions", None)
                if actions is None:
                    raise RuntimeError("reasoning step_wait has no matching step_async")
                raw_reasoning_steps.append(
                    (actions, [info.get("reasoning_trace") for info in infos])
                )
                return result

            env.step_async = MethodType(capture_reasoning_step_async, env)
            env.step_wait = MethodType(capture_reasoning_step_wait, env)

        try:
            with self.autocast_context():
                if self.nosl_is_az:
                    result = self._collect_nosl_is_az_rollouts(
                        env, callback, rollout_buffer, n_rollout_steps, use_masking
                    )
                elif not self.performance_profile:
                    result = super().collect_rollouts(
                        env, callback, rollout_buffer, n_rollout_steps, use_masking
                    )
                else:
                    result = self._collect_profiled_rollouts(
                        env, callback, rollout_buffer, n_rollout_steps, use_masking
                    )
        finally:
            env.step_wait = original_step_wait
            env.step_async = original_step_async

        if result and self.hierarchical_combat_hp:
            self._apply_hierarchical_returns(rollout_buffer, captured)
        if result and reasoning_enabled:
            if len(raw_reasoning_steps) != rollout_buffer.buffer_size:
                raise RuntimeError(
                    "reasoning transition capture length mismatch: "
                    f"{len(raw_reasoning_steps)} != "
                    f"{rollout_buffer.buffer_size}"
                )
            # RolloutBuffer stores the observation that preceded each action;
            # snapshot it before RolloutBuffer.get() swaps/ flattens the
            # arrays in place.  The compiler is pure CPU work, so run it while
            # PPO performs its GPU backward pass and join only immediately
            # before the reasoning loss consumes it.  One batch copy is much
            # cheaper than copying every field for every env at every step.
            observation_snapshot = {
                key: np.array(value, copy=True)
                for key, value in rollout_buffer.observations.items()
            }
            self._reasoning_rollout_samples = []
            self._reasoning_compile_error = None
            self._reasoning_compile_thread = Thread(
                target=self._compile_reasoning_samples,
                args=(raw_reasoning_steps, observation_snapshot),
                name="reasoning-trace-compile",
                daemon=True,
            )
            self._reasoning_compile_thread.start()
        else:
            self._reasoning_rollout_samples = []
        return result

    def _collect_nosl_is_az_rollouts(
        self, env, callback, rollout_buffer, n_rollout_steps, use_masking=True
    ):
        """Collect a whole-run rollout with worker-side combat search.

        This is intentionally close to sb3-contrib's MaskablePPO collector.
        The only extra work is (1) obtaining public policy logits, (2) asking
        each combat worker for a NOSL search decision, and (3) retaining the
        search target for the AZ update.  Overworld actions remain ordinary PPO
        samples.
        """
        from stable_baselines3.common.vec_env import VecEnv

        if not isinstance(env, VecEnv):
            raise TypeError("NOSL-IS-AZ collection requires a VecEnv")
        if not is_masking_supported(env):
            raise ValueError("NOSL-IS-AZ requires an action-masking VecEnv")
        assert self._last_obs is not None
        self.policy.set_training_mode(False)
        rollout_buffer.reset()
        callback.on_rollout_start()
        self._nosl_is_az_samples = []
        combat_phase = V.PHASE_VOCAB_INDEX["combat"]
        # AlphaZero value labels are only known when the current fight ends.
        # Keep each environment's roots across rollout boundaries and label the
        # whole sequence only when the real fight ends.
        active_combat_samples = getattr(
            self, "_nosl_is_az_pending_fights", None
        )
        if (
            not isinstance(active_combat_samples, list)
            or len(active_combat_samples) != env.num_envs
        ):
            active_combat_samples = [[] for _ in range(env.num_envs)]
        self._nosl_is_az_pending_fights = active_combat_samples
        incomplete_combat_roots = 0
        completed_combat_roots = 0
        completed_combat_boundaries = 0
        completed_combats = 0
        cpp_leaf_batches = 0
        cpp_leaf_evaluations = 0
        # Keep the staged NOSL pipeline measurable.  These counters include
        # worker IPC where named, so the next run can distinguish simulator
        # work from Python packing and learner inference without sampling every
        # individual leaf.
        nosl_timings = {
            "root_policy_seconds": 0.0,
            "cpp_begin_rpc_seconds": 0.0,
            "cpp_leaf_decode_seconds": 0.0,
            "cpp_leaf_model_seconds": 0.0,
            "cpp_backprop_rpc_seconds": 0.0,
            "env_step_seconds": 0.0,
        }
        n_steps = 0
        action_masks = None
        started = time.perf_counter()

        while n_steps < n_rollout_steps:
            policy_started = time.perf_counter()
            with th.inference_mode():
                # Root, leaf, and learner batches use the same compact
                # dtype-packed transport.  The router still selects only the
                # fields needed by each phase after this value-preserving move.
                obs_tensor = _leaf_observation_as_tensor(
                    self._last_obs, self.device
                )
                if use_masking:
                    action_masks = get_action_masks(env)
                # Whole-run policies expose this core API.  Keeping a strict
                # check here makes failures explicit for unsupported policies.
                core = getattr(self.policy, "core", None)
                if core is None or not hasattr(core, "actor_critic"):
                    raise TypeError(
                        "NOSL-IS-AZ requires a policy exposing core.actor_critic"
                    )
                compact_cpp_observations = bool(
                    self.nosl_is_az_cpp
                    and hasattr(core, "combat_actor_critic")
                    and hasattr(core, "combat_observation_keys")
                )
                logits, values = core.actor_critic(obs_tensor)
                distribution = self.policy.action_dist.proba_distribution(
                    action_logits=logits
                )
                if action_masks is not None:
                    distribution.apply_masking(action_masks)
                actions = distribution.get_actions(deterministic=False)
                values = values.float()
            nosl_timings["root_policy_seconds"] += (
                time.perf_counter() - policy_started
            )

            actions_np = actions.cpu().numpy().reshape(-1)
            # BF16 autocast tensors do not have a numpy representation on
            # several PyTorch versions; IPC always receives public FP32 logits.
            logits_np = logits.detach().float().cpu().numpy()
            values_np = values.detach().float().cpu().numpy().reshape(-1)
            phase = np.asarray(self._last_obs["phase"]).reshape(
                env.num_envs, -1
            )[:, 0]
            for env_index, phase_id in enumerate(phase):
                if int(phase_id) == combat_phase or not active_combat_samples[env_index]:
                    continue
                # The environment can be externally reset between collectors.
                # Such roots have no objective terminal HP and must not leak
                # into the next fight.
                incomplete_combat_roots += len(active_combat_samples[env_index])
                active_combat_samples[env_index] = []
            if action_masks is None:
                action_masks = np.ones(
                    (env.num_envs, int(self.action_space.n)), dtype=bool
                )
            # Run NOSL PUCT simulations in the workers, but evaluate every
            # non-terminal leaf with the current learner network in batches.
            # ``env_method`` broadcasts one argument tuple; the batch helper
            # sends distinct logits/nonces to all combat workers concurrently.
            combat_indices = [
                index for index in range(env.num_envs)
                if int(phase[index]) == combat_phase
            ]
            result_by_index = {}
            if combat_indices:
                def call_workers(method_name, calls):
                    batch_call = getattr(env, "env_method_batch", None)
                    if batch_call is not None:
                        return batch_call(method_name, calls)
                    return {
                        index: env.env_method(
                            method_name,
                            *args,
                            indices=index,
                            **kwargs,
                        )[0]
                        for index, (args, kwargs) in calls.items()
                    }

                begin_calls = {}
                for env_index in combat_indices:
                    state_nonce = (
                        int(self.nosl_is_az_master_nonce)
                        ^ (int(self.num_timesteps) * 0x9E3779B97F4A7C15)
                        ^ (int(n_steps) * 0xD1B54A32D192ED03)
                        ^ int(env_index)
                    )
                    if self.nosl_is_az_cpp:
                        begin_calls[env_index] = (
                            (logits_np[env_index],),
                            {
                                "state_nonce": state_nonce,
                                "simulations": self.nosl_is_az_simulations,
                                "depth": self.nosl_is_az_depth,
                                "end_turn_as_leaf": self.nosl_is_az_end_turn_as_leaf,
                                "c_puct": self.nosl_is_az_c_puct,
                                "leaf_batch_size": self.nosl_is_az_leaf_batch_size,
                                "dirichlet_alpha": self.nosl_is_az_dirichlet_alpha,
                                "dirichlet_epsilon": self.nosl_is_az_dirichlet_epsilon,
                                "root_value": float(values_np[env_index]),
                                "prior_temperature": self.nosl_is_az_prior_temperature,
                                "root_search_mode": self.nosl_is_az_root_search_mode,
                                "paper_full_gumbel": self.nosl_is_az_paper_full_gumbel,
                                "gumbel_candidates": self.nosl_is_az_gumbel_candidates,
                                "gumbel_scale": self.nosl_is_az_gumbel_scale,
                                "gumbel_value_scale": self.nosl_is_az_gumbel_value_scale,
                                "gumbel_max_visit_init": self.nosl_is_az_gumbel_max_visit_init,
                                "gumbel_rescale_q": self.nosl_is_az_gumbel_rescale_q,
                                "gumbel_use_mixed_value": self.nosl_is_az_gumbel_use_mixed_value,
                                "gumbel_interior_uniformity": self.nosl_is_az_gumbel_interior_uniformity,
                                "gumbel_interior_min_visits": 1,
                                "gumbel_interior_coverage_fraction": self.nosl_is_az_gumbel_interior_coverage_fraction,
                                "gumbel_interior_value_mode": self.nosl_is_az_gumbel_interior_value_mode,
                                "gumbel_interior_max_mix_visits": self.nosl_is_az_gumbel_interior_max_mix_visits,
                                "compact_observation": compact_cpp_observations,
                            },
                        )
                    else:
                        begin_calls[env_index] = (
                            (logits_np[env_index],),
                            {
                                "state_nonce": state_nonce,
                                "master_nonce": self.nosl_is_az_master_nonce,
                                "simulations": self.nosl_is_az_simulations,
                                "depth": self.nosl_is_az_depth,
                                "rollout_steps": self.nosl_is_az_rollout_steps,
                                "c_puct": self.nosl_is_az_c_puct,
                                "temperature": self.nosl_is_az_temperature,
                                "dirichlet_alpha": self.nosl_is_az_dirichlet_alpha,
                                "dirichlet_epsilon": self.nosl_is_az_dirichlet_epsilon,
                            },
                        )

                if self.nosl_is_az_cpp:
                    # C++ owns one tree per worker environment.  It returns a
                    # batch of public leaves; all leaves from all workers are
                    # evaluated in one learner/GPU forward, then each worker
                    # receives its updates in one grouped IPC call.
                    rpc_started = time.perf_counter()
                    responses = call_workers(
                        "nosl_is_az_cpp_begin", begin_calls
                    )
                    nosl_timings["cpp_begin_rpc_seconds"] += (
                        time.perf_counter() - rpc_started
                    )
                    active = {
                        index: response
                        for index, response in responses.items()
                        if not response.get("done", False)
                    }
                    for index, response in responses.items():
                        if response.get("done", False):
                            result_by_index[index] = response["result"]

                    while active:
                        decode_started = time.perf_counter()
                        leaf_records = []
                        packed_batches = []
                        for index in sorted(active):
                            response = active[index]
                            # New transport path: the environment has already
                            # stacked each observation field into a contiguous
                            # batch.  Retain only tiny per-leaf metadata here;
                            # this removes a Python dict/np.stack pass from the
                            # hot loop.
                            batch = unpack_nosl_observation_buffer(response)
                            meta = response.get("leaf_meta")
                            if batch is not None and meta is not None:
                                batch_position = len(packed_batches)
                                packed_batches.append((index, batch))
                                for position, item in enumerate(meta):
                                    leaf_records.append(
                                        (index, item, batch_position, position)
                                    )
                            else:
                                for leaf in response.get("leaves", ()):
                                    leaf_records.append((index, leaf))
                        if not leaf_records:
                            raise RuntimeError(
                                "native NOSL AlphaZero returned no leaves before completion"
                            )
                        cpp_leaf_batches += 1
                        cpp_leaf_evaluations += len(leaf_records)
                        if packed_batches:
                            # Batches from different worker processes are
                            # concatenated once per field.  This is still
                            # contiguous and avoids per-leaf Python packing.
                            keys = tuple(packed_batches[0][1])
                            leaf_observations = {
                                key: np.ascontiguousarray(np.concatenate(
                                    [batch[key] for _index, batch in packed_batches],
                                    axis=0,
                                ))
                                for key in keys
                            }
                        else:
                            leaf_observations = {
                                key: np.stack([
                                    np.asarray(leaf["observation"][key])
                                    for _index, leaf in leaf_records
                                ])
                                for key in leaf_records[0][1]["observation"]
                            }
                        nosl_timings["cpp_leaf_decode_seconds"] += (
                            time.perf_counter() - decode_started
                        )
                        relic_width = None
                        if compact_cpp_observations:
                            relic_ids = leaf_observations["relics"]
                            active_columns = np.flatnonzero(
                                np.any(relic_ids != 0, axis=0)
                            )
                            relic_width = (
                                int(active_columns[-1]) + 1
                                if active_columns.size else 1
                            )
                        leaf_tensor = _leaf_observation_as_tensor(
                            leaf_observations, self.device
                        )
                        model_started = time.perf_counter()
                        with th.inference_mode():
                            with self.autocast_context():
                                if compact_cpp_observations:
                                    leaf_logits, leaf_values = (
                                        core.combat_actor_critic(
                                            leaf_tensor,
                                            active_relic_width=relic_width,
                                        )
                                    )
                                else:
                                    leaf_logits, leaf_values = core.actor_critic(
                                        leaf_tensor
                                    )
                        leaf_logits_np = leaf_logits.detach().float().cpu().numpy()
                        leaf_values_np = (
                            leaf_values.detach().float().cpu().numpy().reshape(-1)
                        )
                        nosl_timings["cpp_leaf_model_seconds"] += (
                            time.perf_counter() - model_started
                        )
                        update_payloads = {}
                        for position, record in enumerate(leaf_records):
                            index = record[0]
                            if len(record) == 4 and packed_batches:
                                meta = record[1]
                                needs_policy = bool(meta.get("needs_policy", True))
                                request_id = int(meta["request_id"])
                            else:
                                leaf = record[1]
                                needs_policy = bool(leaf.get("needs_policy", True))
                                request_id = int(leaf["request_id"])
                            policy = (
                                leaf_logits_np[position]
                                if needs_policy
                                else np.zeros(0, dtype=np.float64)
                            )
                            update_payloads.setdefault(index, []).append(
                                (
                                    request_id,
                                    float(leaf_values_np[position]),
                                    policy,
                                )
                            )
                        next_calls = {
                            index: (
                                (updates,),
                                {
                                    "max_leaves": self.nosl_is_az_leaf_batch_size
                                },
                            )
                            for index, updates in update_payloads.items()
                        }
                        rpc_started = time.perf_counter()
                        next_responses = call_workers(
                            "nosl_is_az_cpp_backprop_and_leaf_batch",
                            next_calls,
                        )
                        nosl_timings["cpp_backprop_rpc_seconds"] += (
                            time.perf_counter() - rpc_started
                        )
                        active = {
                            index: response
                            for index, response in next_responses.items()
                            if not response.get("done", False)
                        }
                        for index, response in next_responses.items():
                            if response.get("done", False):
                                result_by_index[index] = response["result"]
                else:
                    requests = call_workers("nosl_is_az_begin", begin_calls)
                    active = {
                        index: request
                        for index, request in requests.items()
                        if not request.get("done", False)
                    }
                    for index, request in requests.items():
                        if request.get("done", False):
                            result_by_index[index] = request["result"]

                    while active:
                        active_indices = sorted(active)
                        leaf_observations = {
                            key: np.stack([
                                np.asarray(active[index]["observation"][key])
                                for index in active_indices
                            ])
                            for key in active[active_indices[0]]["observation"]
                        }
                        leaf_tensor = _leaf_observation_as_tensor(
                            leaf_observations, self.device
                        )
                        with th.inference_mode():
                            with self.autocast_context():
                                leaf_logits, leaf_values = core.actor_critic(
                                    leaf_tensor
                                )
                        leaf_logits_np = (
                            leaf_logits.detach().float().cpu().numpy()
                        )
                        leaf_values_np = (
                            leaf_values.detach().float().cpu().numpy().reshape(-1)
                        )
                        backprop_calls = {
                            index: (
                                (float(leaf_values_np[position]),
                                 leaf_logits_np[position]),
                                {},
                            )
                            for position, index in enumerate(active_indices)
                        }
                        responses = call_workers(
                            "nosl_is_az_backprop", backprop_calls
                        )
                        active = {
                            index: response
                            for index, response in responses.items()
                            if not response.get("done", False)
                        }
                        for index, response in responses.items():
                            if response.get("done", False):
                                result_by_index[index] = response["result"]

            for env_index in range(env.num_envs):
                if int(phase[env_index]) != combat_phase:
                    continue
                result = result_by_index[env_index]
                actions_np[env_index] = int(result["action"])
                active_combat_samples[env_index].append(
                    {
                        # Replay outlives the PPO rollout buffer, so retain an
                        # independent combat-only observation at every root.
                        "observation": {
                            key: np.asarray(self._last_obs[key][env_index]).copy()
                            for key in getattr(
                                core,
                                "combat_observation_keys",
                                self._last_obs.keys(),
                            )
                            if key in self._last_obs
                        },
                        "action_mask": np.asarray(
                            action_masks[env_index], dtype=bool
                        ).copy(),
                        "policy_target": np.asarray(
                            result["visit_policy"], dtype=np.float32
                        ).copy(),
                        "policy_weight": 1.0,
                        # Filled with objective final combat HP below.  The
                        # search root value remains diagnostic only.
                        "value_target": np.nan,
                        "search_value": float(result["root_value"]),
                    }
                )
            actions = th.as_tensor(actions_np, dtype=th.long, device=self.device)
            # Search may replace sampled combat actions.  Recompute their old
            # log-probability so the rollout remains internally consistent even
            # though combat samples are excluded from the PPO objective below.
            log_probs = distribution.log_prob(actions).float()
            env_started = time.perf_counter()
            new_obs, rewards, dones, infos = env.step(actions_np)
            nosl_timings["env_step_seconds"] += (
                time.perf_counter() - env_started
            )
            self.num_timesteps += env.num_envs

            next_phases, next_hp, interrupted = self._next_phase_hp(
                new_obs, dones, infos
            )
            for env_index in range(env.num_envs):
                if int(phase[env_index]) != combat_phase:
                    continue
                # Only the boundary on the action actually taken belongs to
                # this trajectory.  It receives the fight's eventual HP label
                # but no policy target; hypothetical search leaves must never
                # be assigned the selected line's return.
                boundary_observation = infos[env_index].pop(
                    "nosl_value_boundary_observation", None
                )
                if (
                    self.nosl_is_az_end_turn_as_leaf
                    and boundary_observation is not None
                ):
                    action_dim = int(self.action_space.n)
                    active_combat_samples[env_index].append({
                        "observation": {
                            key: np.asarray(value).copy()
                            for key, value in boundary_observation.items()
                        },
                        "action_mask": np.zeros(action_dim, dtype=bool),
                        "policy_target": np.zeros(action_dim, dtype=np.float32),
                        "policy_weight": 0.0,
                        "value_target": np.nan,
                        "search_value": np.nan,
                    })
                    completed_combat_boundaries += 1
                local_terminal = bool(
                    dones[env_index]
                    or next_phases[env_index] != combat_phase
                )
                if not local_terminal:
                    continue
                pending = active_combat_samples[env_index]
                active_combat_samples[env_index] = []
                if interrupted[env_index]:
                    incomplete_combat_roots += len(pending)
                    continue
                completed = _fill_nosl_combat_value_targets(
                    pending, next_hp[env_index]
                )
                self._nosl_is_az_samples.extend(pending)
                completed_combat_roots += completed
                completed_combats += 1

            callback.update_locals(locals())
            if not callback.on_step():
                return False
            self._update_info_buffer(infos, dones)
            n_steps += 1

            actions_for_buffer = actions_np
            if isinstance(self.action_space, spaces.Discrete):
                actions_for_buffer = actions_for_buffer.reshape(-1, 1)
            for idx, done in enumerate(dones):
                if (
                    done
                    and infos[idx].get("terminal_observation") is not None
                    and infos[idx].get("TimeLimit.truncated", False)
                ):
                    terminal_obs = self.policy.obs_to_tensor(
                        infos[idx]["terminal_observation"]
                    )[0]
                    with th.no_grad():
                        terminal_value = self.policy.predict_values(terminal_obs)[0]
                    # ``predict_values`` returns a one-element tensor for a
                    # single terminal observation.  Convert it to a Python
                    # scalar before adding it to the scalar reward slot;
                    # assigning a shape-(1,) array can fail when the reward
                    # buffer uses a NumPy scalar dtype.
                    terminal_value_scalar = float(
                        terminal_value.detach().float().reshape(-1)[0].cpu()
                    )
                    rewards[idx] += self.gamma * terminal_value_scalar

            rollout_buffer.add(
                self._last_obs,
                actions_for_buffer,
                rewards,
                self._last_episode_starts,
                values,
                log_probs,
                action_masks=action_masks,
            )
            self._last_obs = new_obs
            self._last_episode_starts = dones

        with th.no_grad():
            values = self.policy.predict_values(
                obs_as_tensor(new_obs, self.device)
            )
        rollout_buffer.compute_returns_and_advantage(
            last_values=values, dones=dones
        )
        callback.on_rollout_end()
        pending_combat_roots = sum(len(pending) for pending in active_combat_samples)
        self.logger.record(
            "nosl_is_az/incomplete_combat_roots", incomplete_combat_roots
        )
        self.logger.record(
            "nosl_is_az/pending_combat_roots", pending_combat_roots
        )
        self.logger.record(
            "nosl_is_az/completed_combat_roots", completed_combat_roots
        )
        self.logger.record(
            "nosl_is_az/collected_value_boundaries",
            completed_combat_boundaries,
        )
        # Keep a direct copy for the distributed learner.  The SB3 logger can
        # be dumped/reset between collection and the inner update, so relying
        # only on ``name_to_value`` makes these diagnostics disappear from
        # distributed/W&B records.
        self._nosl_is_az_rollout_timings = dict(nosl_timings)
        if self.nosl_is_az_cpp:
            self.logger.record("nosl_is_az/cpp_leaf_batches", cpp_leaf_batches)
            self.logger.record(
                "nosl_is_az/cpp_leaf_evaluations", cpp_leaf_evaluations
            )
            for name, seconds in nosl_timings.items():
                self.logger.record(f"nosl_is_az/{name}", seconds)
        self.logger.record(
            "nosl_is_az/completed_combats", completed_combats
        )
        self.logger.record(
            "nosl_is_az/collection_seconds", time.perf_counter() - started
        )
        if self.performance_profile:
            total = time.perf_counter() - started
            self._performance_rollout = {
                "policy": 0.0,
                "env": total,
                "mask": 0.0,
                "overhead": 0.0,
                "total": total,
                "transitions": n_rollout_steps * env.num_envs,
                "calls": {"policy": n_rollout_steps, "env": n_rollout_steps, "mask": 0},
            }
        self.logger.record("nosl_is_az/combat_roots", len(self._nosl_is_az_samples))
        return True

    def _compile_reasoning_samples(self, raw_reasoning_steps, buffer_observations):
        """Materialize captured traces without blocking the next GPU phase."""
        try:
            reasoning_samples = []
            for step_index, (actions, traces) in enumerate(raw_reasoning_steps):
                observations = {
                    key: np.asarray(value[step_index])
                    for key, value in buffer_observations.items()
                }
                for env_index, trace in enumerate(traces):
                    if trace is None:
                        continue
                    sample = self._reasoning_sample(
                        observations,
                        env_index,
                        int(actions[env_index]),
                        trace,
                    )
                    if sample is not None:
                        reasoning_samples.append(sample)
            self._reasoning_rollout_samples = reasoning_samples
        except BaseException as error:
            self._reasoning_compile_error = error

    def _wait_for_reasoning_samples(self) -> None:
        thread = self._reasoning_compile_thread
        if thread is None:
            return
        thread.join()
        self._reasoning_compile_thread = None
        error = self._reasoning_compile_error
        self._reasoning_compile_error = None
        if error is not None:
            raise error

    @staticmethod
    def _reasoning_sample(observations, env_index, action, trace):
        """Compile one simulator trace and immediately discard its snapshots."""
        from env.core import action_space as A
        from rl.wholerun_reasoning import (
            build_interactive_transcript,
            card_stochastic_flags,
            events_from_snapshots,
        )

        snapshots = trace.get("snapshots") or ()
        events = trace.get("events")
        if events is None:
            if len(snapshots) < 2:
                return None
            events = events_from_snapshots(snapshots)
        action_card = trace.get("action_card")
        flags = card_stochastic_flags(action_card)
        segment, offset = A.segment_of(action)
        transcript = build_interactive_transcript(
            events=events,
            action_segment=segment,
            action_offset=offset,
            action_card=action_card,
            **flags,
        )
        inputs, labels = transcript.teacher_labels()
        return {
            "observation": {
                key: np.asarray(value[env_index]).copy()
                for key, value in observations.items()
            },
            "action": int(action),
            "inputs": np.asarray(inputs, dtype=np.int64),
            "labels": np.asarray(labels, dtype=np.int64),
            "precision": str(trace.get("precision", "atomic")),
            "environment_tokens": int(sum(
                owner == 0 for owner in transcript.owners
            )),
        }

    def _collect_profiled_rollouts(self, env, callback, rollout_buffer,
                                   n_rollout_steps, use_masking):

        timings = {"policy": 0.0, "env": 0.0, "mask": 0.0}
        calls = {"policy": 0, "env": 0, "mask": 0}
        had_forward = "forward" in self.policy.__dict__
        saved_forward = self.policy.__dict__.get("forward")
        original_forward = self.policy.forward
        original_step_wait = env.step_wait
        original_env_method = env.env_method

        def timed_forward(_policy, *args, **kwargs):
            self._sync_device()
            started = time.perf_counter()
            result = original_forward(*args, **kwargs)
            self._sync_device()
            timings["policy"] += time.perf_counter() - started
            calls["policy"] += 1
            return result

        def timed_step_wait(_env):
            started = time.perf_counter()
            result = original_step_wait()
            timings["env"] += time.perf_counter() - started
            calls["env"] += 1
            return result

        def timed_env_method(_env, method_name, *args, **kwargs):
            started = time.perf_counter()
            result = original_env_method(method_name, *args, **kwargs)
            if method_name == "action_masks":
                timings["mask"] += time.perf_counter() - started
                calls["mask"] += 1
            return result

        self.policy.forward = MethodType(timed_forward, self.policy)
        env.step_wait = MethodType(timed_step_wait, env)
        env.env_method = MethodType(timed_env_method, env)
        self._sync_device()
        started = time.perf_counter()
        try:
            result = super().collect_rollouts(
                env, callback, rollout_buffer, n_rollout_steps, use_masking
            )
        finally:
            self._sync_device()
            total = time.perf_counter() - started
            if had_forward:
                self.policy.forward = saved_forward
            else:
                del self.policy.forward
            env.step_wait = original_step_wait
            env.env_method = original_env_method

        transitions = n_rollout_steps * env.num_envs
        known = timings["policy"] + timings["env"] + timings["mask"]
        self._performance_rollout = {
            **timings,
            "overhead": max(0.0, total - known),
            "total": total,
            "transitions": transitions,
            "calls": calls,
        }
        return result

    def _materialize_legacy_nosl_observations(self, samples: list[dict]) -> None:
        """Resolve pre-replay buffer indices used by older callers and tests."""
        missing = [sample for sample in samples if "observation" not in sample]
        if not missing:
            return
        if self.rollout_buffer.generator_ready:
            observations = self.rollout_buffer.observations
        else:
            observations = {
                key: self.rollout_buffer.swap_and_flatten(value)
                for key, value in self.rollout_buffer.observations.items()
            }
        keys = self._nosl_is_az_observation_keys()
        for sample in missing:
            index = int(sample.get("buffer_index", -1))
            if index < 0:
                raise ValueError("NOSL sample has neither observation nor buffer index")
            sample["observation"] = {
                key: np.asarray(observations[key][index]).copy()
                for key in keys
            }

    def _prepare_nosl_is_az_replay(self) -> dict[str, float]:
        """Prepare newly labelled fights for the next AZ update.

        The historical default is replay-enabled for checkpoint
        compatibility.  With replay explicitly disabled, samples remain in a
        short-lived fresh list and are consumed exactly once by the update.
        """
        raw_samples = list(getattr(self, "_nosl_is_az_samples", []))
        samples = [
            sample
            for sample in raw_samples
            if np.isfinite(float(sample.get("value_target", np.nan)))
        ]
        dropped = len(raw_samples) - len(samples)
        self._materialize_legacy_nosl_observations(samples)
        replay_enabled = bool(getattr(self, "nosl_is_az_replay_enabled", True))
        if not replay_enabled:
            self._nosl_is_az_fresh_samples = samples
            self._nosl_is_az_samples = []
            stats = {
                "fresh_roots": float(len(samples)),
                "dropped_unlabeled_roots": float(dropped),
                "replay_size": 0.0,
                "replay_capacity": 0.0,
                "replay_fill_ratio": 0.0,
                "replay_allocated_mb": 0.0,
                "replay_ready": float(bool(samples)),
                "replay_enabled": 0.0,
                "fresh_start_id": 0.0,
            }
            self._nosl_is_az_replay_prepare_stats = stats
            logger = getattr(self, "_logger", None)
            if logger is not None:
                logger.record("nosl_is_az/dropped_unlabeled_roots", dropped)
            return stats

        self._nosl_is_az_fresh_samples = []
        replay = self._ensure_nosl_is_az_replay()
        fresh_start_id = replay.total_added
        added = replay.add_samples(samples)
        self._nosl_is_az_samples = []
        ready = replay.size >= int(self.nosl_is_az_replay_min_size)
        stats = {
            "fresh_roots": float(added),
            "dropped_unlabeled_roots": float(dropped),
            "replay_size": float(replay.size),
            "replay_capacity": float(replay.capacity),
            "replay_fill_ratio": float(replay.size / replay.capacity),
            "replay_allocated_mb": float(replay.allocated_bytes / (1024**2)),
            "replay_ready": float(ready),
            "replay_enabled": 1.0,
            "fresh_start_id": float(fresh_start_id),
        }
        self._nosl_is_az_replay_prepare_stats = stats
        logger = getattr(self, "_logger", None)
        if logger is not None:
            logger.record("nosl_is_az/dropped_unlabeled_roots", dropped)
        return stats

    def _nosl_is_az_replay_train_count(self) -> int:
        if not bool(getattr(self, "nosl_is_az_replay_enabled", True)):
            return len(getattr(self, "_nosl_is_az_fresh_samples", ()))
        replay = self._ensure_nosl_is_az_replay()
        if replay.size < int(self.nosl_is_az_replay_min_size):
            return 0
        return min(int(self.nosl_is_az_batch_size), replay.size)

    def _train_nosl_is_az(
        self,
        *,
        step_optimizer: bool = True,
        gradient_scale: float = 1.0,
        prepare_replay: bool = True,
        update_count: int | None = None,
    ) -> dict[str, object]:
        """Train the combat specialist from a recent self-play replay window.

        One effective batch is sampled without replacement per requested AZ
        update. It is split into bounded microbatches for memory, accumulated as
        an exact sample-weighted mean, and stepped once. Distributed training
        leaves that mean gradient installed for the ring all-reduce. ``update_count``
        is an internal override used by distributed training to run one replay
        update per synchronized optimizer step while retaining the configured
        total number of inner updates.
        """
        if update_count is None:
            update_count = int(self.nosl_is_az_updates)
        else:
            update_count = int(update_count)
        if update_count < 1:
            raise ValueError("NOSL-IS-AZ update_count must be positive")
        if prepare_replay:
            prepare_stats = self._prepare_nosl_is_az_replay()
        else:
            prepare_stats = dict(
                getattr(self, "_nosl_is_az_replay_prepare_stats", {})
            )
        replay_enabled = bool(getattr(self, "nosl_is_az_replay_enabled", True))
        replay = (
            self._ensure_nosl_is_az_replay() if replay_enabled else None
        )
        train_count = self._nosl_is_az_replay_train_count()
        requested_batch_size = int(self.nosl_is_az_batch_size)
        batch_fill_ratio = (
            float(train_count / requested_batch_size)
            if requested_batch_size > 0 else 0.0
        )
        if train_count < 1:
            if not step_optimizer:
                self.policy.optimizer.zero_grad()
            self._nosl_is_az_metric_sums = {}
            self._nosl_is_az_metric_sumsq = {}
            self._nosl_is_az_metric_counts = {}
            self._nosl_is_az_metric_count = 0.0
            self._nosl_is_az_policy_loss_sum = 0.0
            self._nosl_is_az_policy_weight_sum = 0.0
            self._nosl_is_az_value_loss_sum = 0.0
            return {
                "roots": 0.0,
                "policy_loss": 0.0,
                "value_loss": 0.0,
                "updates": 0.0,
                "gradient_batches": 0.0,
                "replay_sampled_roots": 0.0,
                "replay_old_fraction": 0.0,
                "replay_enabled": float(replay_enabled),
                "batch_size_requested": float(requested_batch_size),
                "batch_size_used": 0.0,
                "batch_fill_ratio": 0.0,
                "metric_count": 0.0,
                "gradient_norm_preclip": 0.0,
                **{
                    key: value
                    for key, value in prepare_stats.items()
                    if key != "fresh_start_id"
                },
            }

        core = getattr(self.policy, "core", None)
        if core is None or not hasattr(core, "actor_critic"):
            raise TypeError("NOSL-IS-AZ requires policy core.actor_critic")
        actor_critic = getattr(core, "combat_actor_critic", core.actor_critic)
        micro_batch_size = int(
            getattr(self, "nosl_is_az_micro_batch_size", 2048)
        )
        fresh_start_id = int(
            prepare_stats.get(
                "fresh_start_id", replay.total_added if replay is not None else 0
            )
        )
        fresh_samples = list(
            getattr(self, "_nosl_is_az_fresh_samples", ())
        ) if not replay_enabled else None
        policy_loss_sum = 0.0
        sampled_policy_weight = 0.0
        value_loss_sum = 0.0
        sampled_roots = 0
        sampled_old = 0
        gradient_batches = 0
        optimizer_steps = 0
        gradient_norms = []

        monitor_names = (
            "target_entropy",
            "policy_entropy",
            "target_policy_kl",
            "policy_cross_entropy",
            "target_effective_actions",
            "target_top1_agreement",
            "legal_actions",
            "illegal_target_mass",
            "target_sum_error",
            "value_target",
            "pred_value",
            "value_mae",
            "value_bias",
            "finite_fraction",
        )
        monitor_sum = {name: 0.0 for name in monitor_names}
        monitor_sumsq = {name: 0.0 for name in monitor_names}
        monitor_min = {name: float("inf") for name in monitor_names}
        monitor_max = {name: float("-inf") for name in monitor_names}
        monitor_count = {name: 0 for name in monitor_names}

        def accumulate_monitor(name: str, values: th.Tensor) -> None:
            array = values.detach().float().reshape(-1).cpu().numpy()
            finite = np.isfinite(array)
            if not np.any(finite):
                return
            array = array[finite].astype(np.float64, copy=False)
            monitor_sum[name] += float(array.sum(dtype=np.float64))
            monitor_sumsq[name] += float(np.square(array).sum(dtype=np.float64))
            monitor_min[name] = min(monitor_min[name], float(array.min()))
            monitor_max[name] = max(monitor_max[name], float(array.max()))
            monitor_count[name] += int(array.size)

        for _update in range(update_count):
            indices = replay.sample_indices(train_count) if replay_enabled else None
            if replay_enabled:
                assert indices is not None and replay is not None
                # Materialize the sampled effective batch once.  Slicing this
                # batch below keeps each micro-batch as a view and avoids a
                # replay-buffer advanced-index copy for every forward pass.
                sampled_batch = replay.get_batch(indices)
            else:
                assert fresh_samples is not None
                sampled_batch = self._nosl_samples_to_batch(
                    fresh_samples[:train_count]
                )
            self.policy.optimizer.zero_grad()
            for start in range(0, train_count, micro_batch_size):
                end = min(start + micro_batch_size, train_count)
                micro_count = end - start
                batch = {
                    "observations": {
                        key: value[start:end]
                        for key, value in sampled_batch["observations"].items()
                    },
                    "action_masks": sampled_batch["action_masks"][start:end],
                    "policy_targets": sampled_batch["policy_targets"][start:end],
                    "policy_weights": sampled_batch["policy_weights"][start:end],
                    "value_targets": sampled_batch["value_targets"][start:end],
                    "sample_ids": sampled_batch["sample_ids"][start:end],
                }
                observations = _leaf_observation_as_tensor(
                    {
                        key: np.asarray(
                            value, dtype=self.observation_space[key].dtype
                        )
                        for key, value in batch["observations"].items()
                    },
                    self.device,
                )
                masks = th.as_tensor(
                    batch["action_masks"], dtype=th.bool, device=self.device
                )
                targets = th.as_tensor(
                    batch["policy_targets"],
                    dtype=th.float32,
                    device=self.device,
                )
                value_targets = th.as_tensor(
                    batch["value_targets"],
                    dtype=th.float32,
                    device=self.device,
                )
                policy_weights = th.as_tensor(
                    batch["policy_weights"],
                    dtype=th.float32,
                    device=self.device,
                ).clamp_min(0.0)
                with self.autocast_context():
                    logits, values = actor_critic(observations)
                    masked_logits = th.where(
                        masks, logits, th.full_like(logits, -1.0e8)
                    )
                    log_probs = F.log_softmax(masked_logits, dim=-1)
                    target_sum = targets.sum(dim=-1, keepdim=True).clamp_min(1e-8)
                    target_sum_error = (target_sum.squeeze(-1) - 1.0).abs()
                    targets = targets / target_sum
                    target_positive = targets > 0.0
                    target_log = th.where(
                        target_positive,
                        th.log(targets.clamp_min(1e-8)),
                        th.zeros_like(targets),
                    )
                    target_entropy_per_sample = -(targets * target_log).sum(dim=-1)
                    masked_probs = th.where(
                        masks, th.exp(log_probs), th.zeros_like(log_probs)
                    )
                    prob_sum = masked_probs.sum(dim=-1, keepdim=True).clamp_min(1e-8)
                    masked_probs = masked_probs / prob_sum
                    policy_log = th.where(
                        masked_probs > 0.0,
                        th.log(masked_probs.clamp_min(1e-8)),
                        th.zeros_like(masked_probs),
                    )
                    policy_entropy_per_sample = -(
                        masked_probs * policy_log
                    ).sum(dim=-1)
                    policy_cross_entropy_per_sample = -(
                        targets * log_probs
                    ).sum(dim=-1)
                    policy_kl_per_sample = (
                        policy_cross_entropy_per_sample
                        - target_entropy_per_sample
                    )
                    illegal_target_mass = (
                        targets * (~masks).to(dtype=targets.dtype)
                    ).sum(dim=-1)
                    legal_actions = masks.sum(dim=-1).float()
                    target_top1 = targets.argmax(dim=-1)
                    policy_top1 = masked_probs.argmax(dim=-1)
                    target_top1_agreement = (
                        target_top1 == policy_top1
                    ).float()
                    value_loss_per_sample = F.mse_loss(
                        values.float().flatten(), value_targets,
                        reduction="none",
                    )
                    loss_per_sample = (
                        self.nosl_is_az_policy_coef
                        * policy_cross_entropy_per_sample * policy_weights
                        + self.nosl_is_az_value_coef
                        * value_loss_per_sample
                    )

                # Every sample contributes its exact fraction of the effective
                # batch.  A boundary's zero policy weight removes only its
                # policy gradient while retaining its value supervision.
                backward_loss = (
                    loss_per_sample.sum() / float(train_count)
                )
                if not step_optimizer:
                    backward_loss = backward_loss * float(gradient_scale)
                backward_loss.backward()
                policy_loss_sum += float(
                    (policy_cross_entropy_per_sample * policy_weights)
                    .sum().detach().cpu()
                )
                sampled_policy_weight += float(policy_weights.sum().detach().cpu())
                value_loss_sum += float(value_loss_per_sample.sum().detach().cpu())
                sampled_roots += micro_count
                if replay_enabled:
                    sampled_old += int(
                        np.count_nonzero(batch["sample_ids"] < fresh_start_id)
                    )
                gradient_batches += 1

                pred_values = values.float().flatten()
                target_values = value_targets.float().flatten()
                monitor_values = {
                    "target_entropy": target_entropy_per_sample[policy_weights > 0],
                    "policy_entropy": policy_entropy_per_sample[policy_weights > 0],
                    "target_policy_kl": policy_kl_per_sample[policy_weights > 0],
                    "policy_cross_entropy": policy_cross_entropy_per_sample[policy_weights > 0],
                    "target_effective_actions": th.exp(
                        target_entropy_per_sample
                    )[policy_weights > 0],
                    "target_top1_agreement": target_top1_agreement[policy_weights > 0],
                    "legal_actions": legal_actions[policy_weights > 0],
                    "illegal_target_mass": illegal_target_mass[policy_weights > 0],
                    "target_sum_error": target_sum_error[policy_weights > 0],
                    "value_target": target_values,
                    "pred_value": pred_values,
                    "value_mae": (pred_values - target_values).abs(),
                    "value_bias": pred_values - target_values,
                    "finite_fraction": (
                        th.isfinite(logits).all(dim=-1)
                        & th.isfinite(pred_values)
                    ).float(),
                }
                for name, values_for_metric in monitor_values.items():
                    accumulate_monitor(name, values_for_metric)
            if step_optimizer:
                gradient_norms.append(self._optimizer_step(1))
                optimizer_steps += 1

        if not replay_enabled:
            # Fresh roots are deliberately one-shot.  This also bounds memory
            # when a fight spans many collection updates.
            self._nosl_is_az_fresh_samples = []

        def metric_mean(name: str) -> float:
            return (
                float(monitor_sum[name] / monitor_count[name])
                if monitor_count[name] else 0.0
            )

        def metric_std(name: str) -> float:
            if not monitor_count[name]:
                return 0.0
            mean = monitor_sum[name] / monitor_count[name]
            return float(
                np.sqrt(max(
                    0.0,
                    monitor_sumsq[name] / monitor_count[name] - mean * mean,
                ))
            )

        def metric_minimum(name: str) -> float:
            return 0.0 if not np.isfinite(monitor_min[name]) else float(monitor_min[name])

        def metric_maximum(name: str) -> float:
            return 0.0 if not np.isfinite(monitor_max[name]) else float(monitor_max[name])

        result = {
            "roots": float(sampled_roots),
            "policy_loss": float(
                policy_loss_sum / max(1.0, sampled_policy_weight)
            ),
            "value_loss": float(value_loss_sum / sampled_roots),
            "updates": float(optimizer_steps),
            "gradient_batches": float(gradient_batches),
            "replay_sampled_roots": float(sampled_roots if replay_enabled else 0.0),
            "replay_old_fraction": float(sampled_old / sampled_roots),
            "replay_enabled": float(replay_enabled),
            "batch_size_requested": float(requested_batch_size),
            "batch_size_used": float(train_count),
            "batch_fill_ratio": float(batch_fill_ratio),
            "metric_count": float(monitor_count["value_target"]),
            "target_entropy": metric_mean("target_entropy"),
            "policy_entropy": metric_mean("policy_entropy"),
            "target_policy_kl": metric_mean("target_policy_kl"),
            "policy_cross_entropy": metric_mean("policy_cross_entropy"),
            "target_effective_actions": metric_mean("target_effective_actions"),
            "target_top1_agreement": metric_mean("target_top1_agreement"),
            "legal_actions_mean": metric_mean("legal_actions"),
            "illegal_target_mass": metric_mean("illegal_target_mass"),
            "target_sum_error": metric_mean("target_sum_error"),
            "value_target_mean": metric_mean("value_target"),
            "value_target_std": metric_std("value_target"),
            "value_target_min": metric_minimum("value_target"),
            "value_target_max": metric_maximum("value_target"),
            "pred_value_mean": metric_mean("pred_value"),
            "pred_value_std": metric_std("pred_value"),
            "value_mae": metric_mean("value_mae"),
            "value_bias": metric_mean("value_bias"),
            "finite_fraction": metric_mean("finite_fraction"),
            "gradient_norm_preclip": float(
                np.mean(gradient_norms) if gradient_norms else 0.0
            ),
        }
        result.update(
            {
                key: value
                for key, value in prepare_stats.items()
                if key != "fresh_start_id"
            }
        )
        # Keep exact sums on the runtime object for the distributed caller.
        # They must not be returned in the logger-facing dict: TensorBoard and
        # W&B expect scalar values and reject nested dictionaries.
        self._nosl_is_az_metric_sums = monitor_sum
        self._nosl_is_az_metric_sumsq = monitor_sumsq
        self._nosl_is_az_metric_counts = monitor_count
        self._nosl_is_az_metric_count = float(monitor_count["value_target"])
        self._nosl_is_az_policy_loss_sum = float(policy_loss_sum)
        self._nosl_is_az_policy_weight_sum = float(sampled_policy_weight)
        self._nosl_is_az_value_loss_sum = float(value_loss_sum)
        return result

    def _optimizer_step(self, micro_batches: int) -> float:
        """Average accumulated gradients, clip once, and update parameters."""
        if micro_batches < 1:
            return
        scale = 1.0 / micro_batches
        for parameter in self.policy.parameters():
            if parameter.grad is not None:
                parameter.grad.mul_(scale)
        gradient_norm = th.nn.utils.clip_grad_norm_(
            self.policy.parameters(), self.max_grad_norm
        )
        self.policy.optimizer.step()
        self.policy.optimizer.zero_grad()
        return float(gradient_norm.detach().float().cpu())

    def _train_reasoning(self) -> dict[str, float]:
        self._wait_for_reasoning_samples()
        samples = self._reasoning_rollout_samples
        core = getattr(self.policy, "core", None)
        if (
            not samples
            or self.reasoning_coef <= 0.0
            or self.reasoning_updates <= 0
            or not hasattr(core, "reasoning_loss")
        ):
            return {}

        # All captured transcripts participate.  The decoder can extend its
        # positional representation beyond the initial learned table, so a
        # long trace is no longer silently removed from the auxiliary loss.
        eligible = list(samples)
        dropped = 0
        if not eligible:
            return {
                "samples": float(len(samples)),
                "eligible_samples": 0.0,
                "dropped_too_long": float(dropped),
                "sequence_length_mean": 0.0,
                "sequence_length_max": 0.0,
            }

        losses = []
        accuracies = []
        supervised = 0.0
        sampled_samples = 0
        optimizer_steps = 0
        accumulation_steps = self.reasoning_gradient_accumulation_steps
        self.policy.optimizer.zero_grad()
        for reasoning_update in range(self.reasoning_updates):
            count = min(self.reasoning_batch_size, len(eligible))
            indices = np.random.choice(len(eligible), size=count, replace=False)
            batch = [eligible[int(index)] for index in indices]
            observations = {
                key: th.as_tensor(
                    np.stack([sample["observation"][key] for sample in batch]),
                    device=self.device,
                )
                for key in batch[0]["observation"]
            }
            actions = th.as_tensor(
                [sample["action"] for sample in batch],
                dtype=th.long,
                device=self.device,
            )
            length = max(len(sample["inputs"]) for sample in batch)
            from rl.wholerun_reasoning import IGNORE_INDEX, VOCAB

            input_ids = th.full(
                (count, length), VOCAB.pad_id, dtype=th.long, device=self.device
            )
            labels = th.full(
                (count, length), IGNORE_INDEX, dtype=th.long, device=self.device
            )
            for row, sample in enumerate(batch):
                width = len(sample["inputs"])
                input_ids[row, :width] = th.as_tensor(
                    sample["inputs"], dtype=th.long, device=self.device
                )
                labels[row, :width] = th.as_tensor(
                    sample["labels"], dtype=th.long, device=self.device
                )

            with self.autocast_context():
                reasoning_loss, stats = core.reasoning_loss(
                    observations, actions, input_ids, labels
                )
                weighted_loss = self.reasoning_coef * reasoning_loss
            weighted_loss.backward()
            sampled_samples += count
            group_finished = (
                (reasoning_update + 1) % accumulation_steps == 0
                or reasoning_update + 1 >= self.reasoning_updates
            )
            if group_finished:
                group_size = min(
                    accumulation_steps,
                    reasoning_update + 1
                    - (reasoning_update // accumulation_steps) * accumulation_steps,
                )
                self._optimizer_step(group_size)
                optimizer_steps += 1
            losses.append(float(reasoning_loss.detach().cpu()))
            accuracies.append(stats["token_accuracy"])
            supervised += stats["supervised_tokens"]

        atomic = sum(sample["precision"] == "atomic" for sample in eligible)
        environment_tokens = sum(sample["environment_tokens"] for sample in eligible)
        lengths = [len(sample["inputs"]) for sample in eligible]
        return {
            "loss": float(np.mean(losses)),
            "token_accuracy": float(np.mean(accuracies)),
            "supervised_tokens": supervised,
            "sampled_samples": float(sampled_samples),
            "samples": float(len(samples)),
            "eligible_samples": float(len(eligible)),
            "dropped_too_long": float(dropped),
            "atomic_trace_rate": atomic / len(eligible),
            "environment_tokens": float(environment_tokens),
            "optimizer_steps": float(optimizer_steps),
            "gradient_accumulation_steps": float(accumulation_steps),
            "sequence_length_mean": float(np.mean(lengths)),
            "sequence_length_max": float(max(lengths)),
        }

    def train(self) -> None:
        """Update the policy, accumulating gradients across micro-batches."""
        if self.performance_profile:
            self._sync_device()
            train_started = time.perf_counter()
            if self.device.type == "cuda":
                th.cuda.reset_peak_memory_stats(self.device)
        self.policy.set_training_mode(True)
        self._update_learning_rate(self.policy.optimizer)
        clip_range = self.clip_range(self._current_progress_remaining)  # type: ignore[operator]
        if self.clip_range_vf is not None:
            clip_range_vf = self.clip_range_vf(self._current_progress_remaining)  # type: ignore[operator]

        entropy_losses = []
        pg_losses, value_losses = [], []
        combat_value_losses, overworld_value_losses = [], []
        clip_fractions = []
        valid_samples = combat_samples = overworld_samples = 0
        continue_training = True
        optimizer_steps = 0
        loss = th.zeros((), device=self.device)
        approx_kl_divs = []

        inner_only = bool(getattr(self, "nosl_is_az_inner_only", False))
        ppo_epochs = 0 if inner_only else self.n_epochs
        for epoch in range(ppo_epochs):
            approx_kl_divs = []
            accumulated = 0
            self.policy.optimizer.zero_grad()

            for rollout_data in self.rollout_buffer.get(self.batch_size):
                actions = rollout_data.actions
                if isinstance(self.action_space, spaces.Discrete):
                    actions = rollout_data.actions.long().flatten()

                with self.autocast_context():
                    values, log_prob, entropy = self.policy.evaluate_actions(
                        rollout_data.observations,
                        actions,
                        action_masks=rollout_data.action_masks,
                    )
                values = values.flatten()

                components = ppo_loss_components(
                    hierarchical=self.hierarchical_combat_hp,
                    normalize_advantage=self.normalize_advantage,
                    observations=rollout_data.observations,
                    advantages=rollout_data.advantages,
                    returns=rollout_data.returns,
                    old_values=rollout_data.old_values,
                    old_log_prob=rollout_data.old_log_prob,
                    values=values,
                    log_prob=log_prob,
                    entropy=entropy,
                    clip_range=clip_range,
                    clip_range_vf=(
                        clip_range_vf
                        if self.clip_range_vf is not None else None
                    ),
                    skip_combat=self.nosl_is_az,
                )
                policy_loss = components.policy_loss
                value_loss = components.value_loss
                entropy_loss = components.entropy_loss
                pg_losses.append(policy_loss.item())
                value_losses.append(value_loss.item())
                entropy_losses.append(entropy_loss.item())
                clip_fractions.append(components.clip_fraction.item())
                valid_samples += components.valid_samples
                combat_samples += components.combat_samples
                overworld_samples += components.overworld_samples
                if components.combat_value_loss is not None:
                    combat_value_losses.append(
                        components.combat_value_loss.item()
                    )
                if components.overworld_value_loss is not None:
                    overworld_value_losses.append(
                        components.overworld_value_loss.item()
                    )

                loss = (
                    policy_loss
                    + self.ent_coef * entropy_loss
                    + self.vf_coef * value_loss
                )

                approx_kl_div = float(components.approx_kl.detach().cpu())
                approx_kl_divs.append(approx_kl_div)

                if (
                    self.target_kl is not None
                    and approx_kl_div > 1.5 * self.target_kl
                ):
                    continue_training = False
                    if self.verbose >= 1:
                        print(
                            f"Early stopping at step {epoch} due to reaching "
                            f"max kl: {approx_kl_div:.2f}"
                        )
                    break

                loss.backward()
                accumulated += 1
                if accumulated == self.gradient_accumulation_steps:
                    self._optimizer_step(accumulated)
                    optimizer_steps += 1
                    accumulated = 0

            # Preserve updates from micro-batches preceding a target-KL stop,
            # and support callers whose rollout does not form a complete group.
            if accumulated:
                self._optimizer_step(accumulated)
                optimizer_steps += 1

            self._n_updates += 1
            if not continue_training:
                break

        reasoning_stats = {} if inner_only else self._train_reasoning()
        nosl_is_az_stats = (
            self._train_nosl_is_az() if self.nosl_is_az else {}
        )

        flat_values = self.rollout_buffer.values.flatten()
        flat_returns = self.rollout_buffer.returns.flatten()
        valid_returns = np.isfinite(flat_returns)
        explained_var = explained_variance(
            flat_values[valid_returns],
            flat_returns[valid_returns],
        )

        mean_or_nan = lambda values: np.mean(values) if values else np.nan
        self.logger.record("train/entropy_loss", mean_or_nan(entropy_losses))
        self.logger.record("train/policy_gradient_loss", mean_or_nan(pg_losses))
        self.logger.record("train/value_loss", mean_or_nan(value_losses))
        self.logger.record("train/approx_kl", mean_or_nan(approx_kl_divs))
        self.logger.record("train/clip_fraction", mean_or_nan(clip_fractions))
        self.logger.record("train/loss", loss.item())
        self.logger.record("train/explained_variance", explained_var)
        self.logger.record("train/n_updates", self._n_updates, exclude="tensorboard")
        self.logger.record("train/clip_range", clip_range)
        self.logger.record(
            "train/gradient_accumulation_steps",
            self.gradient_accumulation_steps,
        )
        self.logger.record(
            "train/effective_batch_size",
            self.batch_size * self.gradient_accumulation_steps,
        )
        self.logger.record("train/optimizer_steps", optimizer_steps)
        self.logger.record("train/outer_updates_enabled", float(not inner_only))
        for key, value in reasoning_stats.items():
            self.logger.record(f"reasoning/{key}", value)
        for key, value in nosl_is_az_stats.items():
            self.logger.record(f"nosl_is_az/{key}", value)
        if self.hierarchical_combat_hp:
            flat_phases = np.asarray(
                self.rollout_buffer.observations["phase"]
            )[..., 0].flatten()
            combat_mask = flat_phases == V.PHASE_VOCAB_INDEX["combat"]
            combat_returns = combat_mask & valid_returns
            overworld_returns = ~combat_mask & valid_returns
            self.logger.record("train/valid_samples", valid_samples)
            self.logger.record("train/combat_samples", combat_samples)
            self.logger.record("train/overworld_samples", overworld_samples)
            self.logger.record(
                "train/combat_value_loss",
                np.mean(combat_value_losses) if combat_value_losses else np.nan,
            )
            self.logger.record(
                "train/overworld_value_loss",
                np.mean(overworld_value_losses)
                if overworld_value_losses else np.nan,
            )
            self.logger.record(
                "train/combat_explained_variance",
                explained_variance(
                    flat_values[combat_returns], flat_returns[combat_returns]
                ) if combat_returns.any() else np.nan,
            )
            self.logger.record(
                "train/overworld_explained_variance",
                explained_variance(
                    flat_values[overworld_returns],
                    flat_returns[overworld_returns],
                ) if overworld_returns.any() else np.nan,
            )
        if self.clip_range_vf is not None:
            self.logger.record("train/clip_range_vf", clip_range_vf)

        if self.performance_profile:
            self._sync_device()
            train_seconds = time.perf_counter() - train_started
            rollout = self._performance_rollout
            self.logger.record("perf/train_update_seconds", train_seconds)
            if self.device.type == "cuda":
                self.logger.record(
                    "perf/gpu_peak_memory_mb",
                    th.cuda.max_memory_allocated(self.device) / (1024 ** 2),
                )
            if rollout is not None:
                total = max(rollout["total"], 1e-12)
                transitions = rollout["transitions"]
                for key in ("policy", "env", "mask", "overhead", "total"):
                    self.logger.record(f"perf/rollout_{key}_seconds", rollout[key])
                    self.logger.record(
                        f"perf/rollout_{key}_ms_per_transition",
                        rollout[key] * 1000.0 / transitions,
                    )
                self.logger.record(
                    "perf/rollout_policy_fraction", rollout["policy"] / total
                )
                self.logger.record(
                    "perf/rollout_env_fraction", rollout["env"] / total
                )
                self.logger.record(
                    "perf/rollout_mask_fraction", rollout["mask"] / total
                )
                bottleneck = max(
                    ("gpu-policy", rollout["policy"]),
                    ("cpu-env", rollout["env"]),
                    ("cpu-mask-ipc", rollout["mask"]),
                    ("python-overhead", rollout["overhead"]),
                    key=lambda item: item[1],
                )[0]
                print(
                    "[perf] "
                    f"rollout={rollout['total']:.2f}s "
                    f"gpu_policy={rollout['policy']:.2f}s "
                    f"cpu_env={rollout['env']:.2f}s "
                    f"mask_ipc={rollout['mask']:.2f}s "
                    f"overhead={rollout['overhead']:.2f}s "
                    f"update={train_seconds:.2f}s bottleneck={bottleneck}",
                    flush=True,
                )

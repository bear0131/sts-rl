import os,pathlib,sys,json,subprocess
import numpy as np
root=pathlib.Path(__file__).parent;repo=pathlib.Path(os.environ.get('STS_AUDIT_REPO',os.environ.get('STS_AUDIT_REPO',str(root/'sts-rl-audit'))));sys.path.insert(0,str(repo))
from env.core.run_env import SlayTheSpireEnv
from schemas.combat_state import normalize_sim_global
import slaythespire as sts
results={}
def test(name,fn):
 try:results[name]=fn()
 except Exception as e:results[name]={'error':repr(e)}
 print(name,json.dumps(results[name],ensure_ascii=False),flush=True)
def packed_parity():
 out=[]
 for encounter in ['Jaw Worm','Two Louse','Gremlin Leader']:
  e=SlayTheSpireEnv();e.reset(seed=42);e.thick.gc.floor_num=1
  e.thick.gc.set_deck([('STRIKE_RED',0)]*5+[('DEFEND_RED',0)]*5)
  e.thick.gc.set_relics(['Akabeko']);e.thick.bc=sts.create_battle(e.thick.gc,encounter)
  e._nosl_cpp_global_template=normalize_sim_global(e.thick.gc)
  logits=np.zeros(181);h=next(i for i,c in enumerate(e.thick.bc.to_dict()['hand']) if c[0]=='STRIKE_RED');logits[1+h]=50
  cfg=dict(simulations=1,depth=1,nonce=123)
  s1=e.thick.bc.nosl_neural_search_begin(logits,**cfg);s2=e.thick.bc.nosl_neural_search_begin(logits,**cfg)
  req=s1.next_batch(1)[0];packed=s2.next_batch_packed(1)
  a=e._native_leaf_observation(req['state'],combat_only=True);b=e._native_packed_observation_batch(packed)
  diffs=[]
  for key in a:
   x=np.asarray(a[key]);y=np.asarray(b[key][0])
   if x.shape!=y.shape:diffs.append({'key':key,'shape_a':x.shape,'shape_b':y.shape});continue
   if not np.allclose(x,y):
    where=np.argwhere(~np.isclose(x,y))
    diffs.append({'key':key,'positions':where[:15].tolist(),'legacy':[x[tuple(i)].item() for i in where[:15]],'packed':[y[tuple(i)].item() for i in where[:15]]})
  out.append({'encounter':encounter,'raw_player_powers':req['state']['player']['powers'],'diffs':diffs})
 return out
test('packed_vs_canonical',packed_parity)
def eval_legacy():
 env=os.environ.copy();env.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONIOENCODING='utf-8')
 p=subprocess.run([sys.executable,'-m','rl.eval','artifacts/latest-nosl-az-s512-20260905/nosl_az_307200_steps.zip','--episodes','1','--device','cpu'],cwd=repo,capture_output=True,text=True,encoding='utf-8',timeout=45,env=env)
 (root/'legacy-eval.log').write_text(p.stdout+'\n'+p.stderr,encoding='utf-8')
 return {'exit':p.returncode,'tail':p.stderr[-2000:]}
test('legacy_checkpoint_actual_eval',eval_legacy)
def icecream_boundary():
 from env.core import encode
 from schemas.combat_state import normalize_sim
 gc=sts.GameContext(sts.CharacterClass.IRONCLAD,42,0);gc.floor_num=1;gc.set_relics(['Ice Cream'])
 bc=sts.create_battle(gc,'Jaw Worm');observations=[];states=[]
 for energy in [1,3]:
  b=bc.clone();b.set_player_energy(energy);boundary=b.preview_end_turn_boundary(4<<29)
  observations.append(encode.encode_combat(normalize_sim(boundary)))
  b.execute(sts.Action(sts.ActionType.END_TURN))
  states.append({'before_energy':energy,'boundary_energy':boundary['player']['energy'],'actual_next_turn_energy':b.to_dict()['player']['energy']})
 return {'states':states,'changed_boundary_fields':[k for k in observations[0] if not np.array_equal(observations[0][k],observations[1][k])]}
test('icecream_boundary_aliasing',icecream_boundary)
(root/'latest-probe-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')

import os
import pathlib,zipfile,json,hashlib
r=pathlib.Path(os.environ.get('STS_AUDIT_REPO',str(pathlib.Path(__file__).parent/'sts-rl-audit')))
rows=[]
for p in sorted((r/'artifacts').rglob('*.zip')):
 with zipfile.ZipFile(p) as z:
  d=json.loads(z.read('data'))
  row={'path':str(p.relative_to(r)),'bytes':p.stat().st_size}
  for k in ['num_timesteps','n_steps','n_envs','batch_size','n_epochs','learning_rate','gamma','gae_lambda','hierarchical_combat_hp','nosl_is_az','nosl_is_az_cpp','nosl_is_az_depth','nosl_is_az_simulations','nosl_is_az_inner_only','nosl_is_az_batch_size','nosl_is_az_replay_enabled','policy_kwargs']:
   v=d.get(k)
   if isinstance(v,dict):v={k2:v2 for k2,v2 in v.items() if not k2.startswith(':') and isinstance(v2,(str,int,float,bool,type(None)))}
   row[k]=v
  row['stored_files']=z.namelist()
  rows.append(row)
  print(json.dumps(row,ensure_ascii=False))
(r.parent/'checkpoint-inventory.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')

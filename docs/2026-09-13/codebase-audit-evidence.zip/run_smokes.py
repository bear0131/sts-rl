import os,sys,subprocess,pathlib,json
root=pathlib.Path(__file__).parent
os.environ.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONIOENCODING='utf-8')
out=[]
for mod,args in [('env.scripts.test_pure',[]),('env.scripts.test_combat',[]),('env.scripts.test_game',[]),('env.scripts.test_run_v2',['--episodes','20','--seed','0'])]:
 try:
  p=subprocess.run([sys.executable,'-m',mod,*args],cwd=pathlib.Path(os.environ.get('STS_AUDIT_REPO',str(root/'sts-rl-audit'))),capture_output=True,text=True,encoding='utf-8',timeout=120)
  (root/(mod+'.log')).write_text(p.stdout+'\n'+p.stderr,encoding='utf-8')
  out.append({'module':mod,'exit':p.returncode,'tail':p.stdout[-1600:],'stderr':p.stderr[-1000:]})
 except subprocess.TimeoutExpired:out.append({'module':mod,'timeout':True})
 print(json.dumps(out[-1],ensure_ascii=False),flush=True)
(root/'smoke-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')

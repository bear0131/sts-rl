# Audit evidence — 1325041 (2026-09-13)

See audit-manifest.json for commit, native binary, dependencies and reference-file hashes.
The report and findings are a review: no production source fixes were applied.
The baseline-f3696a9 directory contains earlier results only. All root result files refer to 1325041.

Reproduction:
1. Check out bear0131/sts-rl at the exact reviewed_commit in audit-manifest.json.
2. Build the slaythespire Python extension against Python 3.11. build_audit.sh records the audit host's exact commands/paths; adapt these paths to your host. Set STS_LIGHTSPEED_BUILD_DIR explicitly if multiple native builds exist.
3. Use an isolated environment with the dependency versions in audit-manifest.json (pytest is needed). The audit environment reused installed Torch/SB3 without modifying the user's original environment.
4. Set STS_AUDIT_REPO to the absolute checkout path. Run the Python scripts from this evidence directory. They write JSON/logs alongside themselves; integration_probes.py creates two small PPO smoke ZIPs here.
5. Run python -m pytest rl env/scripts -q from the checkout. run_smokes.py runs the documented simulator smoke modules.

probes.py: seeds, monster/target slots, pending action, Headbutt candidates, terminal HP and Python depth=0.
extra_probes.py: gauntlet Feed, teacher vs native, Impatience and PPO gradient split.
latest_probes.py: packed/canonical parity, actual legacy rl.eval failure, Ice Cream value boundary.
integration_probes.py: CPU PPO update/save/load, archived checkpoint native PUCT/Full Gumbel/strict-paper. It deliberately uses the repository dashboard's legacy-observation adapter to test the working adapted path. latest_probes.py separately preserves the unmodified CLI failure.

These scripts report observations and errors; they are not a complete game correctness suite and generally do not assert the desired post-fix behavior. Test failures must be read in context. The first-version dashboard test failure was fixed upstream; the latest 190-test suite passes despite the additional audit counterexamples.
No proprietary decompiled Java files or large checkpoint binaries are distributed here. Their source identities or repo locations are recorded instead.

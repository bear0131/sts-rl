import os,pathlib,sys,json,time
os.environ.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONIOENCODING='utf-8')
root=pathlib.Path(__file__).parent;repo=pathlib.Path(os.environ.get('STS_AUDIT_REPO',os.environ.get('STS_AUDIT_REPO',str(root/'sts-rl-audit'))));sys.path.insert(0,str(repo))
import torch,numpy as np
torch.set_num_threads(1)
from env.core.run_env import SlayTheSpireEnv
from env.core import action_space as A
from rl.split_policy import SplitStSPointerPolicy
from rl.accumulating_ppo import AccumulatingMaskablePPO
from sb3_contrib import MaskablePPO
from rl import model as M
from rl.dashboard import _observation_for_policy
from env.core.run_env import unpack_nosl_observation_buffer
import slaythespire as sts
results={}
def test(name,fn):
 try:results[name]=fn()
 except Exception as e:results[name]={'error':repr(e)}
 print(name,json.dumps(results[name],ensure_ascii=False),flush=True)
def ppo_smoke():
 out=[]
 for hierarchical in [False,True]:
  env=SlayTheSpireEnv()
  m=AccumulatingMaskablePPO(SplitStSPointerPolicy,env,n_steps=32,batch_size=8,n_epochs=1,gradient_accumulation_steps=2,hierarchical_combat_hp=hierarchical,policy_kwargs=dict(d_model=32,n_layers=2,n_heads=4),device='cpu',seed=1)
  before={k:v.clone() for k,v in m.policy.state_dict().items()}
  m.learn(64)
  changed=sum(not torch.equal(before[k],v) for k,v in m.policy.state_dict().items())
  path=root/f'ppo-smoke-{hierarchical}.zip';m.save(path)
  loaded=AccumulatingMaskablePPO.load(path,device='cpu')
  out.append({'hierarchical':hierarchical,'timesteps':m.num_timesteps,'changed_tensors':changed,'finite':all(torch.isfinite(v).all().item() for v in m.policy.state_dict().values()),'save_load_equal':all(torch.equal(v,loaded.policy.state_dict()[k]) for k,v in m.policy.state_dict().items())})
  env.close()
 return out
test('ppo_optimizer_roundtrip',ppo_smoke)
def checkpoint_search():
 p=repo/'artifacts/latest-nosl-az-s512-20260905/nosl_az_307200_steps.zip'
 m=MaskablePPO.load(p,device='cpu');m.policy.set_training_mode(False)
 env=SlayTheSpireEnv(global_map_view=M.uses_global_map_observation(m),card_language=M.uses_card_language(m),combat_language=M.uses_combat_language(m),deck_size_observation=M.uses_deck_size_observation(m),neow_observation=M.uses_neow_observation(m),event_option_observation=M.uses_event_option_observation(m))
 env.reset(seed=42);env.thick.gc.floor_num=1;env.thick.bc=sts.create_battle(env.thick.gc,'Two Louse');env._invalidate_backend_cache()
 out=[]
 for mode,strict in [(0,False),(2,False),(2,True)]:
  b=env.fork_combat();obs=b._obs()
  with torch.no_grad(): logits,values=m.policy.core.actor_critic(m.policy.obs_to_tensor(_observation_for_policy(m,obs))[0])
  response=b.nosl_is_az_cpp_begin(logits[0].numpy(),state_nonce=123,simulations=8,depth=0,leaf_batch_size=1 if strict else 4,root_value=values.flatten()[0].item(),root_search_mode=mode,paper_full_gumbel=strict)
  leaves_n=0
  for _ in range(100):
   if response['done']:break
   updates=[]
   batch=unpack_nosl_observation_buffer(response)
   for i,leaf in enumerate(response['leaves']):
    ob={k:value[i] for k,value in batch.items()}
    with torch.no_grad():l,v=m.policy.core.actor_critic(m.policy.obs_to_tensor(_observation_for_policy(m,ob))[0])
    updates.append((leaf['request_id'],v.flatten()[0].item(),l[0].numpy()))
   leaves_n+=len(updates);response=b.nosl_is_az_cpp_backprop_and_leaf_batch(updates,max_leaves=1 if strict else 4)
  if not response['done']:raise RuntimeError('100 iterations exhausted')
  r=response['result'];o,reward,term,trunc,info=b.step(r['action'])
  out.append({'mode':mode,'strict':strict,'used_dashboard_legacy_observation_filter':True,'leaves':leaves_n,'simulations':r['simulations'],'policy_sum':float(r['visit_policy'].sum()),'action':r['action'],'selected_target':r['selected_target'],'target_training_mass':float(r['visit_policy'][A._TARGET:A._TARGET+5].sum()),'used_completed_policy':r['used_completed_policy'],'pending_after_step':b._pending,'illegal':info.get('illegal',False)})
 return {'checkpoint':str(p.relative_to(repo)),'results':out}
test('checkpoint_native_search',checkpoint_search)
(root/'integration-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')

import os
import sys,pathlib,json,copy
import numpy as np
repo=pathlib.Path(os.environ.get('STS_AUDIT_REPO',str(pathlib.Path(__file__).parent/'sts-rl-audit')));sys.path.insert(0,str(repo))
from env.core.run_env import SlayTheSpireEnv
from env.core import encode,action_space as A,vocab as V
import slaythespire as sts
from schemas.combat_state import normalize_sim

results={}
def test(name,fn):
 try: results[name]=fn()
 except Exception as e: results[name]={'error':repr(e)}
 print(name,json.dumps(results[name],ensure_ascii=False),flush=True)

def make_env(deck,encounter='Jaw Worm',seed=1,relics=None):
 e=SlayTheSpireEnv();e.reset(seed=seed)
 e.thick.gc.set_deck([(x,0) for x in deck]);e.thick.gc.floor_num=1
 if relics is not None:e.thick.gc.set_relics(relics)
 e.thick.bc=sts.create_battle(e.thick.gc,encounter)
 e._invalidate_backend_cache()
 return e

def seed_stream():
 seq=[]
 for _ in range(2):
  e=SlayTheSpireEnv();row=[]
  for s in [42,None,None]:
   e.reset(seed=s);row.append(int(e.thick.gc.seed))
  seq.append(row)
 return {'streams':seq,'equal':seq[0]==seq[1]}
test('seed_stream',seed_stream)

def monster_slots():
 e=make_env(['STRIKE_RED']*5,'Gremlin Leader')
 raw=e.thick.bc.to_dict();canon=normalize_sim(raw);obs=e._obs()
 mask=e.action_masks();h=int(np.flatnonzero(mask[A._PLAY:A._PLAY+A.HAND_SLOTS])[0])
 e.step(A._PLAY+h)
 return {'raw_ids':[x['id'] for x in raw['monsters']], 'canonical_ids':[x['id'] for x in canon['monsters']], 'target_offsets':(np.flatnonzero(e.action_masks()[A._TARGET:A._TARGET+5])).tolist(),'obs_ids':obs['monster_id'].tolist()}
test('monster_slot_mismatch',monster_slots)

def pending_obs():
 e=make_env(['BASH','STRIKE_RED','STRIKE_RED','DEFEND_RED','DEFEND_RED'],'Two Louse')
 hand=e.thick.bc.to_dict()['hand'];idx=[next(i for i,c in enumerate(hand) if c[0]==n) for n in ['BASH','STRIKE_RED']]
 branches=[e.fork_combat() for _ in idx];ob=[]
 for b,h in zip(branches,idx):ob.append(b.step(A._PLAY+h)[0])
 return {'hand':hand,'pending':[b._pending for b in branches],'different_obs_keys':[k for k in ob[0] if not np.array_equal(ob[0][k],ob[1][k])], 'same_masks':np.array_equal(branches[0].action_masks(),branches[1].action_masks())}
test('pending_source_invisible',pending_obs)

def headbutt():
 e=make_env(['HEADBUTT','STRIKE_RED','DEFEND_RED','DEFEND_RED','BASH'])
 bc=e.thick.bc;bc.set_player_energy(10)
 for name in ['DEFEND_RED','STRIKE_RED','HEADBUTT']:
  h=next(i for i,c in enumerate(bc.to_dict()['hand']) if c[0]==name)
  bc.execute(sts.Action(sts.ActionType.CARD,h,0))
 e._invalidate_backend_cache();o=e._obs()
 return {'select_info':bc.select_info(),'discard':bc.to_dict()['discard'],'hand':bc.to_dict()['hand'],'select_ids':o['select_card_ids'].tolist(),'legal_pick_indices':np.flatnonzero(e.action_masks()[A._PICK:A._PICK+A.G_MAX]).tolist()}
test('headbutt_candidates_missing',headbutt)

def native_hp():
 e=make_env(['STRIKE_RED']*5,relics=['Burning Blood']);bc=e.thick.bc;bc.set_player_strength(999)
 gc=e.thick.gc;gc.cur_hp=50
 # Recreate after changing HP.
 bc=sts.create_battle(gc,'Jaw Worm');bc.set_player_strength(999);bc.execute(sts.Action(sts.ActionType.CARD,0,0))
 return {'outcome':bc.to_dict()['outcome'],'raw_terminal_hp':bc.to_dict()['player']['hp'],'python_projected_terminal_hp':bc.projected_exit_hp(gc)}
test('native_vs_learner_terminal_hp',native_hp)

def depth_zero():
 from rl.nosl_is_az import NOSLISAZSession,NOSLISAZConfig
 from rl.nosl_sampler import NOSLSampler
 from rl.test_nosl_is_az import _Branch
 env=_Branch();session=NOSLISAZSession(env,env.action_masks(),prior_logits=np.array([0.,5.,0.]),sampler=NOSLSampler(1),state_nonce=2,decision_index=0,config=NOSLISAZConfig(simulations=8,depth=0))
 state=session.next_request();steps=[]
 while not state['done']:
  steps.append(session.pending[0].thick.bc.steps)
  state=session.backprop(0.5,np.array([0.,5.,0.]))
 return {'leaf_step_counts':steps,'root_visits':state['result']['root_visits'].tolist(),'visit_policy':state['result']['visit_policy'].tolist()}
test('python_depth_zero',depth_zero)

(pathlib.Path(__file__).parent/'probe-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')

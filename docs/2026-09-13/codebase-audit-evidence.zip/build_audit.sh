#!/usr/bin/env bash
set -euo pipefail
cd /c/Users/netsz/Documents/Codex/2026-09-13/ojk/work/sts-rl-audit
PYBIN=$(/d/zxb/my/sts-rl-workbench/sts-rl/.venv/Scripts/python.exe -c 'import sys; print(sys._base_executable)')
cmake -S sim/sts_lightspeed -B sim/sts_lightspeed/build -G Ninja -DCMAKE_CXX_COMPILER=g++ -DPYBIND11_FINDPYTHON=ON -DPython_EXECUTABLE="$PYBIN"
cmake --build sim/sts_lightspeed/build --target slaythespire -j 4
cp /c/Strawberry/c/bin/{libgcc_s_seh-1,libstdc++-6,libwinpthread-1}.dll sim/sts_lightspeed/build/

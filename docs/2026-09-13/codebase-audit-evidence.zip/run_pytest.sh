#!/usr/bin/env bash
set -euo pipefail
cd /c/Users/netsz/Documents/Codex/2026-09-13/ojk/work/sts-rl-audit
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONIOENCODING=utf-8 PYTHONHASHSEED=0
../audit-venv/Scripts/python.exe -m pytest rl env/scripts -q --disable-warnings --junitxml=../pytest.xml > ../pytest.log 2>&1

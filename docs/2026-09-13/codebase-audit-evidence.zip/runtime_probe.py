import os
import sys,importlib.util,importlib.metadata,json
print('base',sys._base_executable)
for m in ['torch','numpy','gymnasium','sb3_contrib','stable_baselines3','pytest','ray']:
 try: print(m,importlib.metadata.version(m.replace('_','-')))
 except Exception as e: print(m,type(e).__name__)

import os
import pathlib,sys,json,random,copy
import numpy as np
root=pathlib.Path(__file__).parent
sys.path.insert(0,os.environ.get('STS_AUDIT_REPO',str(root/'sts-rl-audit')))
from env.core.combat_backend import SimCombatBackend
import slaythespire as sts
results={}
def test(name,fn):
 try: results[name]=fn()
 except Exception as e: results[name]={'error':repr(e)}
 print(name,json.dumps(results[name],ensure_ascii=False),flush=True)

def gauntlet():
 def factory(rng):
  def make():
   gc=sts.GameContext(sts.CharacterClass.IRONCLAD,42,0)
   gc.floor_num=1;gc.set_deck([('FEED',0)]*5);gc.set_relics([])
   return gc
  return make,lambda gc:'Jaw Worm'
 b=SimCombatBackend(factory);b.reset(seed=42)
 before=b.bc.to_dict()['player'];b.bc.set_player_strength(999)
 b.bc.execute(sts.Action(sts.ActionType.CARD,0,0))
 after=b.bc.to_dict()['player'];b._settle()
 return {'before':before,'after_feed':after,'next_fight':b.bc.to_dict()['player'],'wins':b.combats_won}
test('gauntlet_feed',gauntlet)

def teacher():
 import rl.make_vector_rule_training_data as T
 from rl.rule_vector_model import StateVectorConfig
 config=StateVectorConfig();rng=random.Random(0);out=[]
 for card,native in [('Carnage','CARNAGE'),('Impervious','IMPERVIOUS'),('Inflame','INFLAME')]:
  action={'id':card,'up':0}
  s=T._canonical_state(rng,1,'Jaw Worm','normal',[],[],action,[action])
  s['combat']['player'].update(powers={'Frail':1},block=0,energy=10)
  for m in s['combat']['monsters']:m.update(powers={},block=0,hp=100,max_hp=100)
  for p in ['draw','discard','exhaust']:s['combat'][p]=[]
  original=T._make_event;states=[]
  def capture(*a,**kw):
   ret=original(*a,**kw);states.append(copy.deepcopy(ret));return ret
  T._make_event=capture
  try: events=T._effect_record(s,action,config,rng)
  finally:T._make_event=original
  gc=sts.GameContext(sts.CharacterClass.IRONCLAD,42,0);gc.floor_num=1
  gc.set_deck([(native,0)]+[('DEFEND_RED',0)]*4);gc.set_relics([])
  bc=sts.create_battle(gc,'Jaw Worm')
  # Match Frail using binding if available, else compare destination only.
  if hasattr(bc,'set_player_status'):bc.set_player_status('FRAIL',1)
  h=next(i for i,c in enumerate(bc.to_dict()['hand']) if c[0]==native)
  bc.execute(sts.Action(sts.ActionType.CARD,h,0));actual=bc.to_dict()
  out.append({'card':card,'teacher_final_hand':states[-1]['combat']['hand'],'teacher_final_discard':states[-1]['combat']['discard'],'teacher_final_exhaust':states[-1]['combat']['exhaust'],'teacher_block':states[-1]['combat']['player']['block'],'native_discard':actual['discard'],'native_exhaust':actual['exhaust'],'native_block':actual['player']['block'],'native_frail_set':hasattr(bc,'set_player_status')})
 return out
test('teacher_card_conservation',teacher)

def impatience():
 for seed in range(20):
  gc=sts.GameContext(sts.CharacterClass.IRONCLAD,seed,0);gc.floor_num=1
  gc.set_deck([('IMPATIENCE',0)]+[('STRIKE_RED',0)]*9);gc.set_relics([])
  bc=sts.create_battle(gc,'Jaw Worm');before=bc.to_dict()
  ids=[c[0] for c in before['hand']]
  if 'IMPATIENCE' not in ids:continue
  bc.execute(sts.Action(sts.ActionType.CARD,ids.index('IMPATIENCE'),0));after=bc.to_dict()
  return {'seed':seed,'before_hand':before['hand'],'after_hand':after['hand'],'before_draw_n':len(before['draw']),'after_draw_n':len(after['draw'])}
test('impatience_with_attacks',impatience)

def accum():
 import torch as t
 from rl.accumulating_ppo import ppo_loss_components
 def grad(slices):
  p=t.tensor(0.,requires_grad=True);a=t.tensor([1.,2.,10.,30.]);x=t.tensor([1.,3.,2.,8.]);z=t.zeros(4)
  for sl in slices:
   v=ppo_loss_components(hierarchical=False,normalize_advantage=True,observations={},advantages=a[sl],returns=z[sl],old_values=z[sl],old_log_prob=z[sl],values=z[sl],log_prob=p*x[sl],entropy=z[sl],clip_range=.2,clip_range_vf=None)
   (v.policy_loss/len(slices)).backward()
  return p.grad.item()
 return {'full_batch_gradient':grad([slice(None)]),'two_microbatch_mean_gradient':grad([slice(0,2),slice(2,4)])}
test('accumulation_not_full_batch',accum)
(root/'extra-probe-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
